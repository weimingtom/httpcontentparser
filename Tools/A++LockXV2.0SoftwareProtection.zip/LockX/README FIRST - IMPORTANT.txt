Ok... thanks for opening this.
Open LOCKX.vbg if you want to see the sample project and want to learn
how to use it. 
Then to use the ActiveX control in your own project,
copy LockX.ocx to your Windows System directory.
Then just add LockX to your project using Visual Basic.
If you cant find LockX.ocx, simply recompile the ActiveX control

Note: Project done in Microsoft Visual Basic 6.0 Pro on Service Pack 5
No extra DLLs required except those used by the above platform.
