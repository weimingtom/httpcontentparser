/******************************************************************************

$Author$
  
$Modtime$
$Revision$

Description: Interface of class "CECViewApp"
             (application, which displays all countries
              of the European community)

$Log$

******************************************************************************/

/*** Declaration of class "CECViewApp" ***************************************/
class CECViewApp: public CWinApp
{
  // Overrides
	// ClassWizard generated virtual function overrides
	public:
	virtual BOOL InitInstance();

  // Implementation
	afx_msg void OnAppAbout();

	DECLARE_MESSAGE_MAP()
};

extern CECViewApp theApp;    // The one and only CECViewApp object
