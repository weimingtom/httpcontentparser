//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ECView.rc
//
#define IDD_ABOUTBOX                    100
#define IDS_COUNTRY                     102
#define IDS_AREA                        103
#define IDS_POPULATION                  104
#define IDS_CAPITAL                     105
#define IDS_FILTER                      106
#define IDR_MAINFRAME                   128
#define IDR_ECVIEWTYPE                  129
#define IDB_HDRUP                       148
#define IDB_HDRDOWN                     149
#define IDR_AUSTRIA                     200
#define IDR_BELGIUM                     201
#define IDR_BULGARIA                    202
#define IDR_CYPRUS                      203
#define IDR_CZECH                       204
#define IDR_DENMARK                     205
#define IDR_ESTONIA                     206
#define IDR_FINLAND                     207
#define IDR_FRANCE                      208
#define IDR_GERMANY                     209
#define IDR_GREAT_BRITAIN               210
#define IDR_GREECE                      211
#define IDR_HUNGARY                     212
#define IDR_IRELAND                     213
#define IDR_ITALY                       214
#define IDR_LATVIA                      215
#define IDR_LITHUANIA                   216
#define IDR_LUXEMBOURG                  217
#define IDR_MALTA                       218
#define IDR_NETHERLANDS                 219
#define IDR_POLAND                      220
#define IDR_PORTUGAL                    221
#define IDR_ROMANIA                     222
#define IDR_SLOVAKIA                    223
#define IDR_SLOVENIA                    224
#define IDR_SPAIN                       225
#define IDR_SWEDEN                      226
#define IDS_FLAG                        227
#define ID_COLOR_SORT_COLUMN            32771
#define ID_SORT_ARROW                   32772
#define ID_KEEP_LABEL_LEFT              32773
#define ID_SUBITEM_IMAGES               32774
#define ID_CHECKBOXES                   32775
#define ID_HOT_UNDERLINING              32776
#define ID_LOAD_BACKGROUNDIMAGE         32778
#define ID_CLEAR_BACKGROUNDIMAGE        32780
#define ID_VIEW_EXPLORERSTYLE           32781
#define ID_Menu                         32782
#define ID_VIEW_COLUMNSEPARATORS        32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        228
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           328
#endif
#endif
