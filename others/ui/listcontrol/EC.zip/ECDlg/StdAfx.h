/******************************************************************************

$Author$
  
$Modtime$
$Revision$

Description: Includes all standard header files.

$Log$

******************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE

#include <afx.h>
#include <afxcmn.h>
#include <afxcview.h>
#include <afxdlgs.h>
#include <afxdisp.h>
#include <afxtempl.h>
#include <shlwapi.h>
#if _MSC_VER >= 1500
  #include <vsstyle.h>
#endif
#include "resource.h"
