//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ECDlg.rc
//
#define IDM_ABOUTBOX                    0x10
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EC_DIALOG                   102
#define IDS_COUNTRY                     102
#define IDS_AREA                        103
#define IDS_POPULATION                  104
#define IDS_CAPITAL                     105
#define IDS_FILTER                      106
#define IDR_MAINFRAME                   128
#define IDB_HDRUP                       148
#define IDB_HDRDOWN                     149
#define IDR_AUSTRIA                     200
#define IDR_BELGIUM                     201
#define IDR_BULGARIA                    202
#define IDR_CYPRUS                      203
#define IDR_CZECH                       204
#define IDR_DENMARK                     205
#define IDR_ESTONIA                     206
#define IDR_FINLAND                     207
#define IDR_FRANCE                      208
#define IDR_GERMANY                     209
#define IDR_GREAT_BRITAIN               210
#define IDR_GREECE                      211
#define IDR_HUNGARY                     212
#define IDR_IRELAND                     213
#define IDR_ITALY                       214
#define IDR_LATVIA                      215
#define IDR_LITHUANIA                   216
#define IDR_LUXEMBOURG                  217
#define IDR_MALTA                       218
#define IDR_NETHERLANDS                 219
#define IDR_POLAND                      220
#define IDR_PORTUGAL                    221
#define IDR_ROMANIA                     222
#define IDR_SLOVAKIA                    223
#define IDR_SLOVENIA                    224
#define IDR_SPAIN                       225
#define IDR_SWEDEN                      226
#define IDS_FLAG                        227
#define IDI_ICON2                       229
#define IDC_COUNTRIES                   1000
#define IDC_CHECK_SORTCOLOR             1001
#define IDC_CHECK_SORTARROW             1003
#define IDC_CHECK_CHECKBOXES            1004
#define IDC_CHECK_SUBIMAGES             1005
#define IDC_CHECK_LABEL_IMAGE           1006
#define IDC_CHECK_UNDERLINE_HOT         1007
#define IDC_BTN_LOADBKIMG               1008
#define IDC_BTN_CLEARBKIMG              1009
#define IDC_CHECK1                      1010
#define IDC_CHECK_EXPLORER_STYLE        1010
#define IDC_CHECK2                      1011
#define IDC_CHECK_COLUMNSEPARATORS      1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        230
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           1110
#endif
#endif
