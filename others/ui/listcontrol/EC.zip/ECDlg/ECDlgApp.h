/******************************************************************************

$Author$
  
$Modtime$
$Revision$

Description: Interface of class "CECDlgApp"
             (application, which displays all countries
              of the European community)

$Log$

******************************************************************************/

/*** Declaration of class "CECDlgApp" ****************************************/
class CECDlgApp: public CWinApp
{
  public:
  // Overrides
	// ClassWizard generated virtual function overrides
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};

extern CECDlgApp theApp;
