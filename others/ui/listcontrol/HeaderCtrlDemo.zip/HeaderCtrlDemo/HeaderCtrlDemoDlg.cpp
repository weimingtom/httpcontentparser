// HeaderCtrlDemoDlg.cpp : implementation file
//
// Written by Matt Weagle (matt_weagle@hotmail.com)
// Copyright (c) 2000
// 
// Modified: 
//		11.19.2000
//		Initial release
//
// This code may be used in compiled form in any way you desire. This
// file may be redistributed unmodified by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name is included. If 
// the source code in this file is used in any commercial application 
// then a simple email would be nice.
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability if it causes any damage to your
// computer, causes your pet cat to fall ill, increases baldness or
// makes you car start emitting strange noises when you start it up.
//
// Expect bugs.
// 
// Please use and enjoy. Please let me know of any bugs/mods/improvements 
// that you have found/implemented and I will fix/incorporate them into this
// file. 
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "HeaderCtrlDemo.h"
#include "HeaderCtrlDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "HyperLink.h"

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CHyperLink	m_cEmail;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_EMAIL, m_cEmail);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHeaderCtrlDemoDlg dialog

CHeaderCtrlDemoDlg::CHeaderCtrlDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHeaderCtrlDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHeaderCtrlDemoDlg)
	m_nCol = 0;
	m_strColText = _T("");
	m_bAutoUpdate = TRUE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHeaderCtrlDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHeaderCtrlDemoDlg)
	DDX_Control(pDX, IDC_HDR_MSG_EDIT, m_cHeaderMsg);
	DDX_Control(pDX, IDC_SET_HDR_COL_SPIN, m_cColSpin);
	DDX_Control(pDX, IDC_LIST_HDR_EDIT, m_cEditListHdr);
	DDX_Control(pDX, IDC_LIST_CTRL, m_cListCtrl);
	DDX_Text(pDX, IDC_SET_HDR_COL, m_nCol);
	DDV_MinMaxInt(pDX, m_nCol, 0, 1000);
	DDX_Text(pDX, IDC_SET_HDR_COL_TEXT, m_strColText);
	DDX_Check(pDX, IDC_AUTO_TRACK, m_bAutoUpdate);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
/* 
For an explanation why we need to edit the ClassWizard entries to handle the 
Header notification messages, see:

http://support.microsoft.com/support/kb/articles/Q250/6/14.ASP?LN=EN-US&SD=gn&FR=0

The basic problem is that ClassWizard thinks that the list control will be forwarding
the header messages, but in reality, the Header control forwards them to its parent,
the list control.  In this case the messages never make it to the list control's
parent, which is us.  Since the Header control always has an ID of zero (0), we 
simply hardcode this into the message map.  If you have more than one header control
then additional filtering would be required.
*/
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CHeaderCtrlDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CHeaderCtrlDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_LIST_HDR, OnListHdr)
	ON_BN_CLICKED(IDC_SET_HDR, OnSetHdr)
	ON_NOTIFY(HDN_ITEMCLICK, 0, OnItemclickListCtrl)
	ON_NOTIFY(HDN_ITEMCHANGED, 0, OnItemchangedListCtrl)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_BN_CLICKED(IDC_ADVANCED_HDR, OnAdvancedHdr)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHeaderCtrlDemoDlg message handlers
BOOL CHeaderCtrlDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	// Set the spin range
	m_cColSpin.SetRange(0,1000);

	// Initialize some items in the list control
	InitListCtrl();
	
	// Set the header images
	InitHeaderCtrl();
	
	// If autoupdate, then refresh the display
	if (m_bAutoUpdate)
		OnListHdr();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CHeaderCtrlDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHeaderCtrlDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHeaderCtrlDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/////////////////////////////////////////////////////////////////////////////
/*
	InitListCtrl

	Initialization function called from OnInitDialog which creates some 
	columns and inserts items in those columns.  For more information on
	working with the ListCtrl itself, see:

	
	Params:
		None

	Returns:
		None
*/
/////////////////////////////////////////////////////////////////////////////
void CHeaderCtrlDemoDlg::InitListCtrl()
{	

	// Set full row selection
	ListView_SetExtendedListViewStyleEx(m_cListCtrl.GetSafeHwnd(), LVS_EX_FULLROWSELECT , LVS_EX_FULLROWSELECT);

	// Create the columns
	CRect rect;
	m_cListCtrl.GetClientRect(&rect);
	int nInterval = rect.Width()/5;
	m_cListCtrl.InsertColumn(0, _T("Item"), LVCFMT_LEFT, nInterval*2);
	m_cListCtrl.InsertColumn(1, _T("Type"), LVCFMT_LEFT, nInterval);

	// The next one is a bit of a kludge since we are making it right aligned with an image.  The
	// control isn't smart enough to size in this case, so we offset by the width of the image (16)
	m_cListCtrl.InsertColumn(2, _T("Price"), LVCFMT_LEFT, rect.Width()-3*nInterval-16); 

	// Put 10 items in the list
	LV_ITEM lvi;
	TCHAR szItem[256];
	lvi.mask = LVIF_TEXT;
	for (int i=0; i  < 15; i++)
	{
		// First item
		lvi.iItem = i;
		lvi.iSubItem = 0;
		_stprintf(szItem, _T("Item %d"), i);
		lvi.pszText = szItem;
		m_cListCtrl.InsertItem(&lvi);

		// SubItem 1
		lvi.iSubItem = 1;
		_stprintf(szItem, _T("%d"), rand()%10);
		lvi.pszText = szItem;
		m_cListCtrl.SetItem(&lvi);

		// SubItem 2
		lvi.iSubItem = 2;
		float f = (float)((i%4)*10 + 10);
		_stprintf(szItem, _T("$%.2f"), f);
		m_cListCtrl.SetItem(&lvi);

	}
	

}

/////////////////////////////////////////////////////////////////////////////
/*
	OnListHdr

	When the user clicks the "List Header Text" button, we first get a pointer
	to the Header control and then iterate through all of the columns.   For
	each column, we retrieve the column header text and append it to the History
	Edit control
	
	Params:
		None

	Returns:
		None
*/
/////////////////////////////////////////////////////////////////////////////
void CHeaderCtrlDemoDlg::OnListHdr() 
{
	// Get a CHeaderCtrl pointer
	CHeaderCtrl *pHeader = m_cListCtrl.GetHeaderCtrl();
	ASSERT(pHeader);
	
	// Clear the list
	m_cEditListHdr.SetWindowText(_T(""));


	// Setup the structure to get the items
	HDITEM hdi;
	hdi.mask = HDI_WIDTH | HDI_TEXT;
	TCHAR szItem[256];
	hdi.pszText = szItem;
	hdi.cchTextMax = 256;
	for (int i=0; i < pHeader->GetItemCount(); i++)
	{	
		pHeader->GetItem(i, &hdi);

		// Format this item for the history control
		CString str;
		str.Format(_T("Col: %d, Text: %s, Width: %d"), i, hdi.pszText, hdi.cxy);
		m_cEditListHdr.AppendString(str);

		// Reset the buffer
		hdi.cchTextMax = 256;
	}	
}

/////////////////////////////////////////////////////////////////////////////
/*
	OnSetHdr

	When the user wants to update the header control information, first
	verify that they have specified a valid column, then update the text 
	using a CHeaderCtrl::SetItem call
	
	Params:
		None

	Returns:
		None
*/
/////////////////////////////////////////////////////////////////////////////
void CHeaderCtrlDemoDlg::OnSetHdr() 
{
	// Get a CHeaderCtrl pointer
	CHeaderCtrl *pHeader = m_cListCtrl.GetHeaderCtrl();
	ASSERT(pHeader);

	UpdateData(TRUE);
	if (m_nCol >= pHeader->GetItemCount())
	{
		CString str;
		str.Format(_T("Please specify a column\nindex between %d and %d."), 0, pHeader->GetItemCount()-1);
		AfxMessageBox(str, MB_ICONSTOP);

		// Set the focus to the spin edit control
		CEdit *pEditWnd = static_cast<CEdit*>(GetDlgItem(IDC_SET_HDR_COL));
		ASSERT(pEditWnd);
		pEditWnd->SetFocus();
		pEditWnd->SetSel(0, -1);

		return;
	}

	// Update this item
	HDITEM hdi;
	hdi.mask = HDI_TEXT;
	hdi.pszText = (LPTSTR)(LPCTSTR)m_strColText;
	pHeader->SetItem(m_nCol, &hdi);	

	// If autoupdate, then refresh the display
	if (m_bAutoUpdate)
		OnListHdr();

}

/////////////////////////////////////////////////////////////////////////////
/* 
	InitHeaderCtrl

	Initialization function to populate the header control with images and
	setup the hot tracking option.  

	Params
		None

	Returns
		None
*/
/////////////////////////////////////////////////////////////////////////////


// There are three format styles for header controls.  This array is used
// when we first insert the items to show the different alignment options
// for the CHeaderCtrl
UINT g_uHDRStyles[3] = {HDF_LEFT, HDF_CENTER, HDF_RIGHT};

void CHeaderCtrlDemoDlg::InitHeaderCtrl()
{
	// Get a CHeaderCtrl pointer
	CWnd *pWnd = m_cListCtrl.GetDlgItem(0);
	ASSERT(pWnd);
	CHeaderCtrl *pHeader = static_cast<CHeaderCtrl*>(pWnd); //m_cListCtrl.GetHeaderCtrl();
	ASSERT(pHeader);
	
	// Create the image list and attach it to the header control
	VERIFY(m_cImageList.Create(IDB_HEADER_CTRL, 16, 4, RGB(255, 0, 255)));
	pHeader->SetImageList(&m_cImageList);

	// Iterate through the items and set the image
	HDITEM hdi;
	hdi.mask = HDI_IMAGE | HDI_FORMAT;
	for (int i=0; i < pHeader->GetItemCount(); i++)
	{
		if (pHeader->GetItem(i, &hdi))
		{
			hdi.fmt |= g_uHDRStyles[i%3] | HDF_IMAGE;
			hdi.iImage= i;
			pHeader->SetItem( i, &hdi );
		}
		else
		{
			CString msg;
			msg.Format(_T("Unable to get item: %d"), i);
			AfxMessageBox(msg);
		}

	}
	
   // Make the header control track 
   pHeader->ModifyStyle(0, HDS_HOTTRACK);

}


/////////////////////////////////////////////////////////////////////////////
/* 
	OnItemclickListCtrl

	WM_NOTIFY handler for the HDN_ITEMCLICK message.  In this handler we 
	first override the ClassWizard provided structure, since according to the
	documentation this supercedes the HD_NOTIFY structure.  Then we figure
	out what happened and output the text to the history edit control.

	Params
		pNMHDR	pointer to NMHEADER structure containing information about
				selected item.
		pResult	return code for handler

	Returns
		None
*/
/////////////////////////////////////////////////////////////////////////////
void CHeaderCtrlDemoDlg::OnItemclickListCtrl(NMHDR* pNMHDR, LRESULT* pResult) 
{
//	HD_NOTIFY *phdn = (HD_NOTIFY *) pNMHDR;
	NMHEADER *pHdr = (NMHEADER*)pNMHDR;

	// Get a pointer to the header control and figure out what happened
	CHeaderCtrl *pHeader = m_cListCtrl.GetHeaderCtrl();
	ASSERT(pHeader);
	HDITEM hdi;
	hdi.mask = HDI_TEXT;
	TCHAR szItem[256];
	hdi.pszText = szItem;
	hdi.cchTextMax = 256;
	pHeader->GetItem(pHdr->iItem, &hdi);
	CString str;
	str.Format(_T("(HDN_ITEMCLICK) User selected column: %d, Title: %s"), pHdr->iItem, hdi.pszText);
	m_cHeaderMsg.AppendString(str);

	
	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////
/* 
	OnItemchangedListCtrl

	WM_NOTIFY handler for the HDN_ITEMCHANGED message.  In this handler we 
	first override the ClassWizard provided structure, since according to the
	documentation this supercedes the HD_NOTIFY structure.  Then we figure
	out what happened and output the text to the history edit control.  This handler
	is only called when the column width changes, not when the text is changed
	for an existing item.

	Params
		pNMHDR	pointer to NMHEADER structure containing information about
				selected item.
		pResult	return code for handler

	Returns
		None
*/
/////////////////////////////////////////////////////////////////////////////
void CHeaderCtrlDemoDlg::OnItemchangedListCtrl(NMHDR* pNMHDR, LRESULT* pResult) 
{
//	HD_NOTIFY *phdn = (HD_NOTIFY *) pNMHDR;
	NMHEADER *pHdr = (NMHEADER*)pNMHDR;

	// Get a pointer to the header control and figure out what happened
	CHeaderCtrl *pHeader = m_cListCtrl.GetHeaderCtrl();
	ASSERT(pHeader);
	HDITEM hdi;
	hdi.mask = HDI_WIDTH;
	pHeader->GetItem(pHdr->iItem, &hdi);
	CString str;
	str.Format(_T("(HDN_ITEMCHANGED) Column: %d, width: %d"), pHdr->iItem, hdi.cxy);
	m_cHeaderMsg.AppendString(str);
	
	// If autoupdate, then refresh the display
	UpdateData(TRUE);
	if (m_bAutoUpdate)
		OnListHdr();

	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////
/* 
	OnInitDialog

	Initialization for the CAboutDlg which sets the email address.

	Params
		None

	Returns
		None
*/
/////////////////////////////////////////////////////////////////////////////
BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_cEmail.SetURL(_T("mailto:matt_weagle@hotmail.com"));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
/* 
	OnAbout

	Command handler for the About button.  Just show the CAboutDlg.

	Params
		None

	Returns
		None
*/
/////////////////////////////////////////////////////////////////////////////
void CHeaderCtrlDemoDlg::OnAbout() 
{
	// TODO: Add your control notification handler code here
	CAboutDlg	dlg;
	dlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
/* 
	OnAdvancedHdr

	Show the Advanced header dialog which includes the CAdvHeaderCtrl
	subclassed control.

	Params
		None

	Returns
		None
*/
/////////////////////////////////////////////////////////////////////////////
void CHeaderCtrlDemoDlg::OnAdvancedHdr() 
{
	// TODO: Add your control notification handler code here
	CAdvHeaderDlg dlg;
	dlg.DoModal();

}

