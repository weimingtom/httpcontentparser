#if !defined(AFX_ADVHEADERDLG_H__CCE43464_B881_4503_A711_EF14C07C68A3__INCLUDED_)
#define AFX_ADVHEADERDLG_H__CCE43464_B881_4503_A711_EF14C07C68A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AdvHeaderDlg.h : header file
//
#include "AdvHeaderCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CAdvHeaderDlg dialog

class CAdvHeaderDlg : public CDialog
{
// Construction
public:
	CAdvHeaderDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAdvHeaderDlg)
	enum { IDD = IDD_HEADER_ADVANCED };
	CListCtrl	m_cListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAdvHeaderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CAdvHeaderCtrl	m_cAdvHeaderCtrl;

	void InitListCtrl();
	void InitHeaderCtrl();

	// Generated message map functions
	//{{AFX_MSG(CAdvHeaderDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADVHEADERDLG_H__CCE43464_B881_4503_A711_EF14C07C68A3__INCLUDED_)
