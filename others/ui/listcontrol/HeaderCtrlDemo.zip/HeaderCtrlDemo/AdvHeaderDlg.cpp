// AdvHeaderDlg.cpp : implementation file
//
// Written by Matt Weagle (matt_weagle@hotmail.com)
// Copyright (c) 2000
// 
// Modified: 
//		11.19.2000
//		Initial release
//
// This code may be used in compiled form in any way you desire. This
// file may be redistributed unmodified by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name is included. If 
// the source code in this file is used in any commercial application 
// then a simple email would be nice.
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability if it causes any damage to your
// computer, causes your pet cat to fall ill, increases baldness or
// makes you car start emitting strange noises when you start it up.
//
// Expect bugs.
// 
// Please use and enjoy. Please let me know of any bugs/mods/improvements 
// that you have found/implemented and I will fix/incorporate them into this
// file. 
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HeaderCtrlDemo.h"
#include "AdvHeaderDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdvHeaderDlg dialog


CAdvHeaderDlg::CAdvHeaderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAdvHeaderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAdvHeaderDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAdvHeaderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdvHeaderDlg)
	DDX_Control(pDX, IDC_LIST_CTRL_EX, m_cListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdvHeaderDlg, CDialog)
	//{{AFX_MSG_MAP(CAdvHeaderDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdvHeaderDlg message handlers

BOOL CAdvHeaderDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitListCtrl();

	m_cAdvHeaderCtrl.Init(m_cListCtrl.GetHeaderCtrl());

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


/////////////////////////////////////////////////////////////////////////////
/*
	InitListCtrl

	Initialization function called from OnInitDialog which creates some 
	columns and inserts items in those columns.  For more information on
	working with the ListCtrl itself, see:

	
	Params:
		None

	Returns:
		None
*/
/////////////////////////////////////////////////////////////////////////////
void CAdvHeaderDlg::InitListCtrl()
{	

	// Set full row selection
	ListView_SetExtendedListViewStyleEx(m_cListCtrl.GetSafeHwnd(), LVS_EX_FULLROWSELECT , LVS_EX_FULLROWSELECT);

	// Create the columns
	CRect rect;
	m_cListCtrl.GetClientRect(&rect);
	int nInterval = rect.Width()/5;
	m_cListCtrl.InsertColumn(0, _T("Item"), LVCFMT_LEFT, nInterval*2);
	m_cListCtrl.InsertColumn(1, _T("Type"), LVCFMT_LEFT, nInterval);

	// The next one is a bit of a hack since we are making it right aligned with an image.  The
	// control isn't smart enough to size in this case, so we offset by the width of the image (16)
	m_cListCtrl.InsertColumn(2, _T("Price"), LVCFMT_LEFT, rect.Width()-3*nInterval-16); 

	// Put 10 items in the list
	LV_ITEM lvi;
	TCHAR szItem[256];
	lvi.mask = LVIF_TEXT;
	for (int i=0; i  < 15; i++)
	{
		// First item
		lvi.iItem = i;
		lvi.iSubItem = 0;
		_stprintf(szItem, _T("Item %d"), i);
		lvi.pszText = szItem;
		m_cListCtrl.InsertItem(&lvi);

		// SubItem 1
		lvi.iSubItem = 1;
		_stprintf(szItem, _T("%d"), rand()%10);
		lvi.pszText = szItem;
		m_cListCtrl.SetItem(&lvi);

		// SubItem 2
		lvi.iSubItem = 2;
		float f = (float)((i%4)*10 + 10);
		_stprintf(szItem, _T("$%.2f"), f);
		m_cListCtrl.SetItem(&lvi);

	}
	

}


/////////////////////////////////////////////////////////////////////////////
/* 
	InitHeaderCtrl

	Initialization function to populate the header control with images and
	setup the hot tracking option.  

	Params
		None

	Returns
		None
*/
/////////////////////////////////////////////////////////////////////////////
void CAdvHeaderDlg::InitHeaderCtrl()
{
}
