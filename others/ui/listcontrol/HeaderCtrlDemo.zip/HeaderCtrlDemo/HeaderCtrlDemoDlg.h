// HeaderCtrlDemoDlg.h : header file
//

#if !defined(AFX_HEADERCTRLDEMODLG_H__3CC23F90_CEBE_4D3C_A69E_9266B7DCC07E__INCLUDED_)
#define AFX_HEADERCTRLDEMODLG_H__3CC23F90_CEBE_4D3C_A69E_9266B7DCC07E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HistoryEdit.h"
#include "AdvHeaderDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CHeaderCtrlDemoDlg dialog

class CHeaderCtrlDemoDlg : public CDialog
{
// Construction
public:
	CHeaderCtrlDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CHeaderCtrlDemoDlg)
	enum { IDD = IDD_HEADERCTRLDEMO_DIALOG };
	CHistoryEdit	m_cHeaderMsg;
	CSpinButtonCtrl	m_cColSpin;
	CHistoryEdit	m_cEditListHdr;
	CListCtrl	m_cListCtrl;
	int		m_nCol;
	CString	m_strColText;
	BOOL	m_bAutoUpdate;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHeaderCtrlDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void InitHeaderCtrl();
	void InitListCtrl();

	CImageList m_cImageList;	
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CHeaderCtrlDemoDlg)
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnListHdr();
	afx_msg void OnSetHdr();
	afx_msg void OnItemclickListCtrl(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangedListCtrl(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnAbout();
	virtual BOOL OnInitDialog();
	afx_msg void OnAdvancedHdr();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HEADERCTRLDEMODLG_H__3CC23F90_CEBE_4D3C_A69E_9266B7DCC07E__INCLUDED_)
