This Zip file contains two templates for use when submitting articles
to The Code Project. We recommend editing these files using DevStudio
or some other text editor. All extraneous formatting will be removed. 

You only need to fill in ONE of these files: If you are comfortable 
with editing ASP, then please use the .ASP template. If you wish to 
edit your articles in a way that allows you to preview the results, 
then use the .HTML template. The ASP template is better for us, but 
the HTML may be easier for you :) 

If you use the HTML template then it will not look like the final product - 
it has been formatted to allow the relevant information to be entered as
quickly and easily as possible. 

Using these templates will help us post your article sooner. We are using 
MS IIS and ASP pages on the server, allowing us to simplify the templates 
used to create the articles.

To fill in either of these templates, just follow the 3 easy steps below:
 
     1. Fill in the article description details
     2. Add links to your images and downloads
     3. Include the main article text

That's all there is to it! All formatting will be done by the ASP script 
engine.


The Code Project
www.codeproject.com