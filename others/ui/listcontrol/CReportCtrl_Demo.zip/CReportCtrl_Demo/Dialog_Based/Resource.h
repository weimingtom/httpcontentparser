//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ReportCtrlDemo.rc
//
#define IDC_SORT                        3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_REPORTCTRLDEMO_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDB_BITMAP1                     130
#define IDB_BITMAP2                     131
#define IDD_STATESDLG                   132
#define IDC_LIST1                       1000
#define IDC_INSERT                      1001
#define IDC_DEL                         1002
#define IDC_DELALL                      1003
#define IDC_DELALLSEL                   1004
#define IDC_DELALLUNSEL                 1005
#define IDC_DELALLCHK                   1006
#define IDC_DELALLUNCHK                 1007
#define IDC_SELALL                      1008
#define IDC_UNSELALL                    1009
#define IDC_CHKALL                      1010
#define IDC_UNCHKALL                    1011
#define IDC_INVSEL                      1012
#define IDC_INVCHK                      1013
#define IDC_SWAP                        1014
#define IDC_MOVEUP                      1015
#define IDC_MOVEDOWN                    1016
#define IDC_MOVETOP                     1017
#define IDC_MOVEBOTTOM                  1018
#define IDC_FULLROW                     1019
#define IDC_GRIDLINES                   1020
#define IDC_CHKBOX                      1021
#define IDC_ALLOWEDIT                   1022
#define IDC_SELECT                      1023
#define IDC_CHECK                       1024
#define IDC_DELETE                      1025
#define IDC_POSITION                    1026
#define IDC_BUTTON1                     1027
#define IDC_ALLOWSORT                   1027
#define IDC_BUTTON2                     1028
#define IDC_EDIT1                       1029
#define IDC_CHK_NONE                    1032
#define IDC_CHK_NORMAL                  1033
#define IDC_CHK_SINGLE                  1034
#define IDC_SELECTED                    1034
#define IDC_CHK_DISABLED                1035
#define IDC_ALL                         1035
#define IDC_UNSELECTED                  1036
#define IDC_CHECKED                     1037
#define IDC_BUTTON3                     1037
#define IDC_UNCHECKED                   1038
#define IDC_FOCUSED                     1039
#define IDC_UNFOCUSED                   1040
#define ID_SELECTION_ALL                32771
#define ID_SELECTION_UNALL              32772
#define ID_SELECTION_INVERT             32773
#define ID_CHECKBOX_ALL                 32775
#define ID_CHECKBOX_UNALL               32776
#define ID_CHECKBOX_INVERT              32777
#define ID_DELETION_ALL                 32778
#define ID_DELETION_SEL                 32779
#define ID_DELETION_UNSEL               32780
#define ID_DELETION_CHK                 32781
#define ID_DELETION_UNCHK               32782
#define ID_POSITION_UP                  32783
#define ID_POSITION_DOWN                32784
#define ID_POSITION_TOP                 32785
#define ID_POSITION_BOTTOM              32786
#define ID_POSITION_SWAP                32787
#define ID_CHK_NONE                     32788
#define ID_CHK_NORMAL                   32789
#define ID_CHK_SINGLE                   32790
#define ID_CHK_DISABLE                  32791

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
