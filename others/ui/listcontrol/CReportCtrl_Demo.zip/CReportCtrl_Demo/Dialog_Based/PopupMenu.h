#ifndef __POPUPMENU_H__
#define __POPUPMENU_H__

BOOL PopupMenu(UINT nMenuID, UINT nSubMenuPos, CWnd* pParentWnd);
BOOL PopupMenu(CMenu* pPopupMenu, CWnd* pParentWnd);

#endif