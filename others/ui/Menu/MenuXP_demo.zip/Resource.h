//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MenuXPApp.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MENUXPTYPE                  129
#define IDI_ICON1                       130
#define IDI_ICON2                       131
#define IDI_ICON3                       132
#define IDI_ICON4                       133
#define IDI_ICON5                       134
#define IDI_ICON6                       135
#define IDI_ICON7                       136
#define IDI_ICON8                       137
#define IDI_ICON9                       138
#define IDI_ICON10                      139
#define IDI_ICON11                      140
#define IDI_ICON12                      141
#define IDB_BACK                        144

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
