// MenuXPAppView.cpp : implementation of the CMenuXPAppView class
//

#include "stdafx.h"
#include "MenuXPApp.h"

#include "MenuXPAppDoc.h"
#include "MenuXPAppView.h"

#include "MenuXP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMenuXPAppView

IMPLEMENT_DYNCREATE(CMenuXPAppView, CView)

BEGIN_MESSAGE_MAP(CMenuXPAppView, CView)
	//{{AFX_MSG_MAP(CMenuXPAppView)
	ON_WM_CONTEXTMENU()
	ON_WM_MEASUREITEM()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMenuXPAppView construction/destruction

CMenuXPAppView::CMenuXPAppView()
{
	// TODO: add construction code here

}

CMenuXPAppView::~CMenuXPAppView()
{
}

BOOL CMenuXPAppView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMenuXPAppView drawing

void CMenuXPAppView::OnDraw(CDC* pDC)
{
	CMenuXPAppDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CMenuXPAppView printing

BOOL CMenuXPAppView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMenuXPAppView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMenuXPAppView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMenuXPAppView diagnostics

#ifdef _DEBUG
void CMenuXPAppView::AssertValid() const
{
	CView::AssertValid();
}

void CMenuXPAppView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMenuXPAppDoc* CMenuXPAppView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMenuXPAppDoc)));
	return (CMenuXPAppDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMenuXPAppView message handlers

void CMenuXPAppView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CMenuXP	*pMenu = new CMenuXP;
	pMenu->CreatePopupMenu();

	pMenu->SetSelectedBarColor(RGB(0x66, 0x99, 0xff));
//	pMenu->SetMenuStyle(CMenuXP::STYLE_XP);
	CBitmap	bmp;
	bmp.LoadBitmap(IDB_BACK);
//	pMenu->SetBackBitmap((HBITMAP)bmp.Detach());

	pMenu->AddSideBar(new CMenuXPSideBar(24, "MenuXP"));
	pMenu->AppendODMenu(0, new CMenuXPText(10, "First Item", AfxGetApp()->LoadIcon(IDI_ICON1)));
	pMenu->AppendSeparator();
	pMenu->AppendODMenu(MF_CHECKED, new CMenuXPText(11, "Checked Item", AfxGetApp()->LoadIcon(IDI_ICON2)));
	pMenu->AppendODMenu(0, new CMenuXPText(12, "Another Item", AfxGetApp()->LoadIcon(IDI_ICON3)));
	pMenu->AppendODMenu(0, new CMenuXPText(13, "No Icon"));
	pMenu->SetDefaultItem(12);
	
	CMenuXP *pPopup = new CMenuXP;
	pPopup->CreatePopupMenu();

	pPopup->SetSelectedBarColor(RGB(0x66, 0x99, 0xff));
//	pPopup->SetMenuStyle(CMenuXP::STYLE_XP);

	pPopup->AddSideBar(new CMenuXPSideBar(24, "Buttons"));
	pPopup->SetSideBarStartColor(RGB(125, 230, 192));
	pPopup->SetSideBarEndColor(RGB(0, 0, 0));
	pPopup->AppendODMenu(0, new CMenuXPButton(21, AfxGetApp()->LoadIcon(IDI_ICON4)));
	pPopup->AppendODMenu(0, new CMenuXPButton(22, AfxGetApp()->LoadIcon(IDI_ICON5)));
	pPopup->AppendODMenu(0, new CMenuXPButton(23, AfxGetApp()->LoadIcon(IDI_ICON6)));
	pPopup->Break();
	pPopup->AppendODMenu(MF_CHECKED, new CMenuXPButton(24, AfxGetApp()->LoadIcon(IDI_ICON7)));
	pPopup->AppendODMenu(0, new CMenuXPButton(25, AfxGetApp()->LoadIcon(IDI_ICON8)));
	pPopup->AppendODMenu(0, new CMenuXPButton(26, AfxGetApp()->LoadIcon(IDI_ICON9)));
	pPopup->Break();
	pPopup->AppendODMenu(0, new CMenuXPButton(27, AfxGetApp()->LoadIcon(IDI_ICON10)));
	pPopup->AppendODMenu(0, new CMenuXPButton(28, AfxGetApp()->LoadIcon(IDI_ICON11)));
	pPopup->AppendODMenu(0, new CMenuXPButton(29, AfxGetApp()->LoadIcon(IDI_ICON12)));

	pMenu->AppendODPopup(0, pPopup, new CMenuXPText(0, "Popup", AfxGetApp()->LoadIcon(IDI_ICON1)));

	pMenu->AppendODMenu(MF_GRAYED, new CMenuXPText(40, "Disabled", AfxGetApp()->LoadIcon(IDI_ICON5)));
	pMenu->AppendODMenu(MF_CHECKED, new CMenuXPText(41, "Checked"));

	pMenu->TrackPopupMenu(TPM_LEFTBUTTON, point.x, point.y, this);

	delete pMenu;
}

void CMenuXPAppView::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	// TODO: Add your message handler code here and/or call default
	HMENU hMenu = AfxGetThreadState()->m_hTrackingMenu;
	CMenu	*pMenu = CMenu::FromHandle(hMenu);
	pMenu->MeasureItem(lpMeasureItemStruct);
	
	CView::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}
