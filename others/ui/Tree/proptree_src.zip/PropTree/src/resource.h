//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PropTree.rc
//
#define IDS_TRUE                        100
#define IDS_FALSE                       101
#define IDS_NOITEMSEL                   102
#define IDS_SELFORINFO                  103
#define IDC_SPLITTER                    1000
#define IDC_FPOINT                      1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2000
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2000
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
