char *qURLencode(char *str);
char *qURLdecode(char *str);