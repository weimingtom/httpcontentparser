// VerticalTreeDlg.h : Header-Datei
//

#if !defined(AFX_VERTICALTREEDLG_H__2AD89464_660C_4E88_90F5_AC528E734BFD__INCLUDED_)
#define AFX_VERTICALTREEDLG_H__2AD89464_660C_4E88_90F5_AC528E734BFD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "CustomVerticalTree.h"

/////////////////////////////////////////////////////////////////////////////
// CVerticalTreeDlg Dialogfeld

class CVerticalTreeDlg : public CDialog
{
// Konstruktion
public:
	CVerticalTreeDlg(CWnd* pParent = NULL);	// Standard-Konstruktor

// Dialogfelddaten
	//{{AFX_DATA(CVerticalTreeDlg)
	enum { IDD = IDD_VERTICALTREE_DIALOG };
	CVerticalTree	m_TestTree;
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CVerticalTreeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	void FillTree(TV_INSERTSTRUCT &treeitem, int depth = 2);
	HICON m_hIcon;

	// Generierte Message-Map-Funktionen
	//{{AFX_MSG(CVerticalTreeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButCustom();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_VERTICALTREEDLG_H__2AD89464_660C_4E88_90F5_AC528E734BFD__INCLUDED_)
