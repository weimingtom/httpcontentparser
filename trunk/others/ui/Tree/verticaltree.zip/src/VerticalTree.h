// VerticalTree.h : Haupt-Header-Datei f�r die Anwendung VERTICALTREE
//

#if !defined(AFX_VERTICALTREE_H__C63F22A2_30D3_4D05_8643_E8319B183880__INCLUDED_)
#define AFX_VERTICALTREE_H__C63F22A2_30D3_4D05_8643_E8319B183880__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole

/////////////////////////////////////////////////////////////////////////////
// CVerticalTreeApp:
// Siehe VerticalTree.cpp f�r die Implementierung dieser Klasse
//

class CVerticalTreeApp : public CWinApp
{
public:
	CVerticalTreeApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CVerticalTreeApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementierung

	//{{AFX_MSG(CVerticalTreeApp)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_VERTICALTREE_H__C63F22A2_30D3_4D05_8643_E8319B183880__INCLUDED_)
