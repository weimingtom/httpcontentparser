// ShellIconDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ShellIconDemo.h"
#include "ShellIconDemoDlg.h"
#include "ShellIcons.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CShellIconDemoDlg dialog

CShellIconDemoDlg::CShellIconDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShellIconDemoDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CShellIconDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_SMALL, m_ListCtrlSmall);
	DDX_Control(pDX, IDC_LIST_LARGE, m_ListCtrlLarge);
}

BEGIN_MESSAGE_MAP(CShellIconDemoDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST_SMALL, OnLvnItemchangedListSmall)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST_LARGE, OnLvnItemchangedListLarge)
END_MESSAGE_MAP()


struct CMyShellIcons
{
	int		nIndex;
	LPCTSTR	szDescription;
} MyIcons[] = {
	{SI_UNKNOWN,					_T("Unknown File Type")},
	{SI_DEF_DOCUMENT,				_T("Default document")},
	{SI_DEF_APPLICATION,			_T("Default application")},
	{SI_FOLDER_CLOSED,				_T("Closed folder")},
	{SI_FOLDER_OPEN,				_T("Open folder")},
	{SI_FLOPPY_514,					_T("5 1/4 floppy")},
	{SI_FLOPPY_35,					_T("3 1/2 floppy")},
	{SI_REMOVABLE,					_T("Removable drive")},
	{SI_HDD,						_T("Hard disk drive")},
	{SI_NETWORKDRIVE,				_T("Network drive")},
	{SI_NETWORKDRIVE_DISCONNECTED,	_T("network drive offline")},
	{SI_CDROM,						_T("CD drive")},
	{SI_RAMDISK,					_T("RAM disk")},
	{SI_NETWORK,					_T("Entire network")},
	{14,_T("?")},
	{SI_MYCOMPUTER,					_T("My computer")},
	{SI_PRINTMANAGER,				_T("Printer manager")},
	{SI_NETWORK_NEIGHBORHOOD,		_T("Network neighborhood")},
	{SI_NETWORK_WORKGROUP,			_T("Network workgroup")},
	{SI_STARTMENU_PROGRAMS,			_T("Start menu programs")},
	{SI_STARTMENU_DOCUMENTS,		_T("Start menu documents")},
	{SI_STARTMENU_SETTINGS,			_T("Start menu settings")},
	{SI_STARTMENU_FIND,				_T("Start menu find")},
	{SI_STARTMENU_HELP,				_T("Start menu help")},
	{SI_STARTMENU_RUN,				_T("Start menu run")},
	{SI_STARTMENU_SUSPEND,			_T("Start menu suspend")},
	{SI_STARTMENU_DOCKING,			_T("Start menu docking")},
	{SI_STARTMENU_SHUTDOWN,			_T("Start menu shut down")},
	{SI_SHARE,						_T("Sharing overlay (hand)")},
	{SI_SHORTCUT,					_T("Shortcut overlay (small arrow)")},
	{SI_PRINTER_DEFAULT,			_T("Default printer overlay (small tick)")},
	{SI_RECYCLEBIN_EMPTY,			_T("Recycle bin empty")},
	{SI_RECYCLEBIN_FULL,			_T("Recycle bin full")},
	{SI_DUN,						_T("Dial-up network folder")},
	{SI_DESKTOP,					_T("Desktop")},
	{SI_CONTROLPANEL,				_T("Control panel")},
	{SI_PROGRAMGROUPS,				_T("Program group")},
	{SI_PRINTER,					_T("Printer")},
	{SI_FONT,						_T("Font Folder")},
	{SI_TASKBAR,					_T("Taskbar")},
	{SI_AUDIO_CD,					_T("Audio CD")},
	{41, _T("?")},
	{42, _T("?")},
	{SI_FAVORITES,					_T("Favorites")},
	{SI_LOGOFF,						_T("Start Menu Logoff")},
	{45, _T("?")},
	{46, _T("?")},
	{SI_LOCK,						_T("Lock")},
	{SI_HIBERNATE,					_T("Hibernate")},
	{-1,0}
};

// CShellIconDemoDlg message handlers

BOOL CShellIconDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// We need one column
	m_ListCtrlSmall.InsertColumn (0, _T("Index"));
	m_ListCtrlSmall.InsertColumn (1, _T("Description"));

	// Add full row selection
	m_ListCtrlSmall.SetExtendedStyle (m_ListCtrlSmall.GetExtendedStyle () | LVS_EX_FULLROWSELECT);

	// Get color depth
	HDC hDC = ::GetDC (NULL);
	bool fHiColor = ::GetDeviceCaps (hDC, NUMCOLORS) == -1;
	::ReleaseDC (NULL, hDC);

	// Create image lists
	m_ImageListSmall.Create (
		GetSystemMetrics (SM_CXSMICON),
		GetSystemMetrics (SM_CYSMICON),
		fHiColor ? (ILC_COLOR32|ILC_MASK) : (ILC_COLOR4|ILC_MASK),
		3, 1 );
	m_ImageListLarge.Create (
		GetSystemMetrics (SM_CYICON),
		GetSystemMetrics (SM_CYICON),
		fHiColor ? (ILC_COLOR32|ILC_MASK) : (ILC_COLOR4|ILC_MASK),
		3, 1 );

	// Set our special shell image list
	m_ListCtrlSmall.SetImageList (&m_ImageListSmall, LVSIL_SMALL);
	m_ListCtrlLarge.SetImageList (&m_ImageListLarge, LVSIL_NORMAL);

	// Populate the list ctrl's
	CMyShellIcons* p = MyIcons;
	int nIndex = 0;
	while (p->nIndex >= 0)
	{
		// Extract small shell icon
		HICON hIcon = ExtractShellIcon (p->nIndex, false);
		m_ImageListSmall.Add (hIcon);
		DestroyIcon (hIcon);

		// Extract large shell icon
		hIcon = ExtractShellIcon (p->nIndex, true);
		m_ImageListLarge.Add (hIcon);
		DestroyIcon (hIcon);

		// Add new items to list ctrl's
		TCHAR szBuf[10];
		_stprintf (szBuf, _T("%d"), p->nIndex);
		m_ListCtrlSmall.InsertItem (nIndex, szBuf, nIndex);
		m_ListCtrlSmall.SetItemText (nIndex, 1, p->szDescription);
		m_ListCtrlLarge.InsertItem (nIndex, p->szDescription, nIndex);

		++nIndex;
		++p;
	}

	// Resize columns
	m_ListCtrlSmall.SetColumnWidth (0, LVSCW_AUTOSIZE_USEHEADER);
	m_ListCtrlSmall.SetColumnWidth (1, LVSCW_AUTOSIZE_USEHEADER);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CShellIconDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CShellIconDemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CShellIconDemoDlg::OnLvnItemchangedListSmall(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	if (pNMLV->uNewState & LVIS_SELECTED) {
		m_ListCtrlLarge.SetItemState (pNMLV->iItem, LVIS_SELECTED, LVIS_SELECTED);
		m_ListCtrlLarge.EnsureVisible (pNMLV->iItem, FALSE);
	}
	*pResult = 0;
}

void CShellIconDemoDlg::OnLvnItemchangedListLarge(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	if (pNMLV->uNewState & LVIS_SELECTED) {
		m_ListCtrlSmall.SetItemState (pNMLV->iItem, LVIS_SELECTED, LVIS_SELECTED);
		m_ListCtrlSmall.EnsureVisible (pNMLV->iItem, FALSE);
	}
	*pResult = 0;
}
