// ExampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "StackedWindowsControl_Demo.h"
#include "ExampleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExampleDlg dialog


CExampleDlg::CExampleDlg(CWnd* pParent /*=NULL*/)
	: CResizableDialog(CExampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExampleDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CExampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CResizableDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExampleDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExampleDlg, CResizableDialog)
	//{{AFX_MSG_MAP(CExampleDlg)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExampleDlg message handlers

BOOL CExampleDlg::OnInitDialog() 
{
	CResizableDialog::OnInitDialog();
	
	// Resizable dialog code
	ShowSizeGrip( FALSE );

	AddAnchor( IDC_STATIC1, TOP_LEFT, TOP_RIGHT );
	AddAnchor( IDC_BAR1, TOP_LEFT, TOP_RIGHT );
	AddAnchor( IDC_RADIO1, TOP_RIGHT );
	AddAnchor( IDC_RADIO2, TOP_RIGHT );
	AddAnchor( IDC_EDIT1, TOP_LEFT, TOP_RIGHT );
	AddAnchor( IDC_COMBO1, TOP_LEFT, TOP_RIGHT );
	AddAnchor( IDC_EDIT2, TOP_LEFT, BOTTOM_RIGHT );
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CExampleDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	//	CResizableDialog::OnOK();
}

void CExampleDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	//	CResizableDialog::OnCancel();
}

void CExampleDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	//	CResizableDialog::OnClose();
	CResizableDialog::OnOK();
}
