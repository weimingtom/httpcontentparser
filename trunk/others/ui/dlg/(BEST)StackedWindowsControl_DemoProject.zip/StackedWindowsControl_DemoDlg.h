// StackedWindowsControl_DemoDlg.h : header file
//

#if !defined(AFX_STACKEDWINDOWSCONTROL_DEMODLG_H__2D86979B_6135_4126_A9B6_F8072093AD4C__INCLUDED_)
#define AFX_STACKEDWINDOWSCONTROL_DEMODLG_H__2D86979B_6135_4126_A9B6_F8072093AD4C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
/////////////////////////////////////////////////////////////////////////////

#include "ResizableDialog.h"

#include "StackedWndCtrl.h"

#include "ExampleDlg.h"

#include "TelltaleButton.h"
#include "JazzUpTellTaleButton.h"

/////////////////////////////////////////////////////////////////////////////
// CStackedWindowsControl_DemoDlg dialog

class CStackedWindowsControl_DemoDlg : public CResizableDialog
{
// Construction
public:
	CStackedWindowsControl_DemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CStackedWindowsControl_DemoDlg)
	enum { IDD = IDD_STACKEDWINDOWSCONTROL_DEMO_DIALOG };
	CStackedWndCtrl	m_JazzedUpStackedWndCtrl;
	CStackedWndCtrl	m_StackedWndCtrl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStackedWindowsControl_DemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	CWnd*		ContentWnd	( int iIndex, CWnd* pParent );

	// Generated message map functions
	//{{AFX_MSG(CStackedWindowsControl_DemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STACKEDWINDOWSCONTROL_DEMODLG_H__2D86979B_6135_4126_A9B6_F8072093AD4C__INCLUDED_)
