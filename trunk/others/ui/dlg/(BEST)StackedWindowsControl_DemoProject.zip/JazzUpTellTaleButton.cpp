// JazzUpTellTaleButton.cpp : implementation file
//

#include "stdafx.h"
#include "StackedWindowsControl_Demo.h"
#include "JazzUpTellTaleButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJazzUpTellTaleButton

CJazzUpTellTaleButton::CJazzUpTellTaleButton()
{
}

CJazzUpTellTaleButton::~CJazzUpTellTaleButton()
{
}

void CJazzUpTellTaleButton::SetIcon( UINT nID )
{
	CShadeButtonST::SetShade( SHS_DIAGSHADE );
	CShadeButtonST::SetIcon( nID );
}


BEGIN_MESSAGE_MAP(CJazzUpTellTaleButton, CShadeButtonST)
	//{{AFX_MSG_MAP(CJazzUpTellTaleButton)
	ON_CONTROL_REFLECT(BN_CLICKED, OnClicked)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJazzUpTellTaleButton message handlers

void CJazzUpTellTaleButton::OnClicked() 
{
	GetParent()->SendMessage( WM_RUBRIC_WND_CLICKED_ON, (WPARAM)this->m_hWnd );
}

void CJazzUpTellTaleButton::OnSize(UINT nType, int cx, int cy) 
{
	CShadeButtonST::OnSize(nType, cx, cy);
	
	CShadeButtonST::SetShade( SHS_DIAGSHADE );
}

