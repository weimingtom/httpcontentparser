//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StackedWindowsControl_Demo.rc
//
#define IDD_STACKEDWINDOWSCONTROL_DEMO_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDI_ICON1                       132
#define IDI_ICON2                       133
#define IDI_ICON3                       134
#define IDI_ICON4                       135
#define IDI_ICON5                       136
#define IDC_SWC                         1000
#define IDC_SWC_JAZZEDUP                1001
#define IDC_EDIT1                       1003
#define IDC_CHECK1                      1004
#define IDC_CHECK2                      1005
#define IDC_RADIO1                      1006
#define IDC_RADIO2                      1007
#define IDC_EDIT2                       1009
#define IDC_COMBO1                      1010
#define IDC_STATIC1                     1011
#define IDC_BAR1                        1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
