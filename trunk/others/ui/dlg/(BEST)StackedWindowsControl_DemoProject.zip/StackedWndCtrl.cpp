// StackedWndCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "StackedWindowsControl_Demo.h"
#include "StackedWndCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStackedWndCtrl

CStackedWndCtrl::CStackedWndCtrl()
{
	m_iRubricHeight = 30;
}

CStackedWndCtrl::~CStackedWndCtrl()
{
	for( int i = 0; i < m_arrPanes.GetSize(); i++ )
	{
		// Delete the rubric window
		m_arrPanes[ i ]->m_pwndRubric->DestroyWindow();

		delete m_arrPanes[ i ]->m_pwndRubric;
		
		// Delete the content window
		m_arrPanes[ i ]->m_pwndContent->DestroyWindow();

		delete m_arrPanes[ i ]->m_pwndContent;
		
		// Delete structure
		delete m_arrPanes[ i ];
	}

	m_arrPanes.RemoveAll();
}

int CStackedWndCtrl::AddPane( CWnd* pwndRubric, CWnd* pwndContent )
{
	// Hide whatever pane's content window is currently shown
	// We will always show the content window of the last pane added
	for( int i = 0; i < m_arrPanes.GetSize(); i++ )
		if( m_arrPanes[ i ]->m_bOpen )
			m_arrPanes[ i ]->m_bOpen = FALSE;

	// Create a new pane structure
	PTDS_PANE pPane = new TDS_PANE;

	if( pPane == NULL )
	{
		AfxMessageBox( "Failed to add a new pane to the stack.\n\nOut of memory." );
		return -1;
	}

	// Copy the pointers to the rubric and content windows
	// Also, set this pane as open
	pPane->m_pwndRubric		= pwndRubric;
	pPane->m_pwndContent	= pwndContent;
	pPane->m_bOpen			= TRUE;

	// Add the new pane to the end of the stack
	int iIndex = m_arrPanes.Add( pPane );

	// Rearrange the stack
	RearrangeStack();

	// Return the index of the new pane
	return iIndex;
}

void CStackedWndCtrl::RearrangeStack()
{
    CRect rFrame;

    GetClientRect( &rFrame );

    for( int i = 0; i < m_arrPanes.GetSize(); i++ )
    {
		// Rubric windows are always visible
        m_arrPanes[ i ]->m_pwndRubric->SetWindowPos(  NULL,
                                                    0,
                                                    rFrame.top,
                                                    rFrame.Width(),
                                                    m_iRubricHeight,
                                                    SWP_NOZORDER | SWP_SHOWWINDOW );

		// Only the content window of the flagged pane is shown
		// All others are hidden if they aren't already
        if( m_arrPanes[ i ]->m_bOpen )
        {
			// From the bottom of the frame, take off as many rubric
			// window's heights as there are left to display
            int iContentWndBottom = rFrame.bottom - ( ( m_arrPanes.GetSize() - i ) * m_iRubricHeight );

            m_arrPanes[ i ]->m_pwndContent->SetWindowPos(   NULL,
                                                            0,
                                                            rFrame.top + m_iRubricHeight,
                                                            rFrame.Width(),
                                                            iContentWndBottom - rFrame.top,
                                                            SWP_NOZORDER | SWP_SHOWWINDOW );

			// The next rubric window will be placed right below
			// this pane's content window
            rFrame.top = iContentWndBottom;
        }
        else
            m_arrPanes[ i ]->m_pwndContent->ShowWindow( SW_HIDE );

		// The top of the frame is offset by the height of a rubric window
        rFrame.top += m_iRubricHeight;
    }
}


BEGIN_MESSAGE_MAP(CStackedWndCtrl, CStatic)
	//{{AFX_MSG_MAP(CStackedWndCtrl)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_RUBRIC_WND_CLICKED_ON, OnRubricWndClicked)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStackedWndCtrl message handlers

void CStackedWndCtrl::PreSubclassWindow() 
{
	// Remove the black frame and clip children to reduce flickering
	ModifyStyle( SS_BLACKFRAME, WS_CLIPCHILDREN );

	CStatic::PreSubclassWindow();
}

void CStackedWndCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CStatic::OnSize(nType, cx, cy);

	RearrangeStack();
}

LRESULT CStackedWndCtrl::OnRubricWndClicked(WPARAM wParam, LPARAM /*lParam*/)
{
	HWND hwndRubric = (HWND)wParam;
	BOOL bRearrange = FALSE;

	for( int i = 0; i < m_arrPanes.GetSize(); i++ )
		if( m_arrPanes[ i ]->m_pwndRubric->m_hWnd == hwndRubric )
		{
			// Rearrange the control only if a rubric window
			// other than the one belonging to the pane that
			// is currently open is clicked on
			if( m_arrPanes[ i ]->m_bOpen == FALSE )
			{
				m_arrPanes[ i ]->m_bOpen = TRUE;
				bRearrange = TRUE;
			}
		}
		else
			m_arrPanes[ i ]->m_bOpen = FALSE;

	if( bRearrange )
		RearrangeStack();

	// In case the rubric window that has sent the message wants to know
	// if the control has been rearranged, return the flag
	return bRearrange;
}
