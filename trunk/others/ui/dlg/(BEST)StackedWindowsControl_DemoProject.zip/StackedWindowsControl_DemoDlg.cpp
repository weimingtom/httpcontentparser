// StackedWindowsControl_DemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "StackedWindowsControl_Demo.h"
#include "StackedWindowsControl_DemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStackedWindowsControl_DemoDlg dialog

CStackedWindowsControl_DemoDlg::CStackedWindowsControl_DemoDlg(CWnd* pParent /*=NULL*/)
	: CResizableDialog(CStackedWindowsControl_DemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStackedWindowsControl_DemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CStackedWindowsControl_DemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CResizableDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStackedWindowsControl_DemoDlg)
	DDX_Control(pDX, IDC_SWC_JAZZEDUP, m_JazzedUpStackedWndCtrl);
	DDX_Control(pDX, IDC_SWC, m_StackedWndCtrl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CStackedWindowsControl_DemoDlg, CResizableDialog)
	//{{AFX_MSG_MAP(CStackedWindowsControl_DemoDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStackedWindowsControl_DemoDlg message handlers

BOOL CStackedWindowsControl_DemoDlg::OnInitDialog()
{
	CResizableDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Resizable dialog code
	ShowSizeGrip( TRUE );

	AddAnchor( IDC_SWC, TOP_LEFT, BOTTOM_CENTER );
	AddAnchor( IDC_SWC_JAZZEDUP, TOP_CENTER, BOTTOM_RIGHT );
	
	// Load panes
	CString				csRubric;
	CTelltaleButton*	pbtRubric;
	CRect				rRect;
	UINT				nCtrlID = 0;

	// "plain" control
	for( int i = 0; i < 5; i++ )
	{
		switch( i )
		{
		case 0:
			csRubric = "  Listbox Control";
		break;
		case 1:
			csRubric = "  Edit Control";
		break;
		case 2:
			csRubric = "  Dialog";
		break;
		case 3:
			csRubric = "  Monthly Calendar Control";
		break;
		case 4:
			csRubric = "  Tree Control";
		break;
		default:
			csRubric = "  Default?";
		}

		pbtRubric = new CTelltaleButton;

		pbtRubric->Create( csRubric, WS_CHILD | BS_LEFT, rRect, &m_StackedWndCtrl, nCtrlID++ );
		pbtRubric->SetFont( GetFont() );
		
		m_StackedWndCtrl.AddPane( pbtRubric, ContentWnd( i, &m_StackedWndCtrl ) );
	}

	CJazzUpTellTaleButton*	pbtJazzedUpRubric;
	UINT					nIconId = IDI_ICON1;
	
	rRect.SetRect( 10, 10, 10, 10 );		// CShadeButtonST crashes on an empty rect
	
	// "jazzed-up" control
	for( i = 0; i < 5; i++ )
	{
		switch( i )
		{
		case 0:
			csRubric	= "Listbox Control";
			nIconId		= IDI_ICON4;
		break;
		case 1:
			csRubric	= "Edit Control";
			nIconId		= IDI_ICON1;
		break;
		case 2:
			csRubric	= "Dialog";
			nIconId		= IDI_ICON3;
		break;
		case 3:
			csRubric	= "Monthly Calendar Control";
			nIconId		= IDI_ICON2;
		break;
		case 4:
			csRubric	= "Tree Control";
			nIconId		= IDI_ICON5;
		break;
		default:
			csRubric = "Default?";
		}

		pbtJazzedUpRubric = new CJazzUpTellTaleButton;

		pbtJazzedUpRubric->Create( csRubric, WS_CHILD, rRect, &m_JazzedUpStackedWndCtrl, nCtrlID++ );
		pbtJazzedUpRubric->SetFont( GetFont() );
		pbtJazzedUpRubric->SetIcon( nIconId );
		
		m_JazzedUpStackedWndCtrl.AddPane( pbtJazzedUpRubric, ContentWnd( i, &m_JazzedUpStackedWndCtrl ) );
	}
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

CWnd* CStackedWindowsControl_DemoDlg::ContentWnd( int iIndex, CWnd* pParent )
{
	switch( iIndex )
	{
	case 0:
	{
		CRect		rEmpty;
		CListBox*	pContent = new CListBox;

		pContent->Create( WS_THICKFRAME | WS_VSCROLL | LBS_NOINTEGRALHEIGHT, rEmpty, pParent, iIndex + 1 );
		pContent->SetFont( GetFont() );

		CString cs;

		for( int i = 0; i < 100; i++ )
		{
			cs.Format( "%d", rand() % 100000 );
			pContent->AddString( cs );
		}

		return pContent;
	}
	break;
	case 1:
	{
		CRect	rEmpty;
		CEdit*	pContent = new CEdit;

		pContent->Create( WS_THICKFRAME | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL, rEmpty, pParent, iIndex + 1 );
		pContent->SetFont( GetFont() );

		pContent->SetWindowText( "This is edit control serves as and fills the entire content window." );

		return pContent;
	}
	break;
	case 2:
	default:			// Default case creates a dialog too
	{
		CExampleDlg* pdlgContent = new CExampleDlg;

		pdlgContent->Create( IDD_DIALOG1, pParent );

		return pdlgContent;
	}
	break;
	case 3:
	{
		CRect			rEmpty;
		CMonthCalCtrl*	pContent = new CMonthCalCtrl;

		pContent->Create( WS_THICKFRAME, rEmpty, pParent, iIndex + 1 );
		//	pContent->SetFont( GetFont() );


		return pContent;
	}
	break;
	case 4:
	{
		CString		cs;
		int			iRand1, iRand2;
		CRect		rEmpty;
		CTreeCtrl*	pContent = new CTreeCtrl;

		pContent->Create( WS_THICKFRAME | TVS_HASLINES | TVS_HASBUTTONS | TVS_LINESATROOT, rEmpty, pParent, iIndex + 1 );
		pContent->SetFont( GetFont() );

		for( int i = 0; i < 10; i++ )
		{
			cs.Format( "Item %d", i + 1 );

			HTREEITEM hti1 = pContent->InsertItem( cs );

			iRand1 = 1 + ( rand() % 4 );

			for( int j = 0; j < iRand1; j++ )
			{
				cs.Format( "Item %d.%d", i + 1, j + 1 );

				HTREEITEM hti2 = pContent->InsertItem( cs, hti1 );

				if( rand() % 2 == 1 )
				{
					iRand2 = 1 + ( rand() % 4 );

					for( int k = 0; k < iRand2; k++ )
					{
						cs.Format( "Item %d.%d.%d", i + 1, j + 1, k + 1 );

						pContent->InsertItem( cs, hti2 );
					}

					pContent->Expand( hti2, TVE_EXPAND );
				}
			}

			pContent->Expand( hti1, TVE_EXPAND );
		}


		return pContent;
	}
	break;
	}

	return (CWnd*)NULL;
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CStackedWindowsControl_DemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CResizableDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CStackedWindowsControl_DemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CStackedWindowsControl_DemoDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	//	CResizableDialog::OnOK();
}

void CStackedWindowsControl_DemoDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	//	CResizableDialog::OnCancel();
}

void CStackedWindowsControl_DemoDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	//	CResizableDialog::OnClose();
	CResizableDialog::OnOK();
}
