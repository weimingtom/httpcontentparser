// StackedWindowsControl_Demo.h : main header file for the STACKEDWINDOWSCONTROL_DEMO application
//

#if !defined(AFX_STACKEDWINDOWSCONTROL_DEMO_H__81F28F3F_D17C_4CE0_812C_D483B5B64F49__INCLUDED_)
#define AFX_STACKEDWINDOWSCONTROL_DEMO_H__81F28F3F_D17C_4CE0_812C_D483B5B64F49__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CStackedWindowsControl_DemoApp:
// See StackedWindowsControl_Demo.cpp for the implementation of this class
//

class CStackedWindowsControl_DemoApp : public CWinApp
{
public:
	CStackedWindowsControl_DemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStackedWindowsControl_DemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CStackedWindowsControl_DemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STACKEDWINDOWSCONTROL_DEMO_H__81F28F3F_D17C_4CE0_812C_D483B5B64F49__INCLUDED_)
