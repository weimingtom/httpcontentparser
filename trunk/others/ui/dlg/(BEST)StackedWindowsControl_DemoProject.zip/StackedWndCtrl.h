#if !defined(AFX_STACKEDWNDCTRL_H__1E392EBA_B6EB_4A1E_B2A1_788DFF740F9B__INCLUDED_)
#define AFX_STACKEDWNDCTRL_H__1E392EBA_B6EB_4A1E_B2A1_788DFF740F9B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StackedWndCtrl.h : header file
//

#include <afxtempl.h>

// The control responds to this message, include in all rubrics
// The wParam must contain the rubric's window handle
#define		WM_RUBRIC_WND_CLICKED_ON		( WM_APP + 04100 )

/////////////////////////////////////////////////////////////////////////////
// CStackedWndCtrl window

class CStackedWndCtrl : public CStatic
{
// Construction
public:
	CStackedWndCtrl();

// Attributes
protected:
	int					m_iRubricHeight;

	typedef struct
	{
		CWnd*			m_pwndRubric;
		CWnd*			m_pwndContent;
		BOOL			m_bOpen;
	} TDS_PANE, *PTDS_PANE;

	CArray<PTDS_PANE, PTDS_PANE>		m_arrPanes;

// Operations
protected:
	void			RearrangeStack		();

public:
	int				AddPane				( CWnd* pwndRubric, CWnd* pwndContent );

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStackedWndCtrl)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CStackedWndCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CStackedWndCtrl)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	afx_msg LRESULT OnRubricWndClicked(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STACKEDWNDCTRL_H__1E392EBA_B6EB_4A1E_B2A1_788DFF740F9B__INCLUDED_)
