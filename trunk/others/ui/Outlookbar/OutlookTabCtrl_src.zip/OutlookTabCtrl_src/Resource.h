//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Project.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_PROJECTYPE                  129
#define IDB_BITMAP1                     200
#define IDB_BITMAP2                     201
#define IDB_BITMAP3                     202
#define IDB_BITMAP4                     203
#define IDB_BACKGROUND                  204
#define IDD_DIALOG                      250
#define IDD_TESTDLG                     251
#define ID_OUTLOOKTABCTRL               300
#define IDR_POPUP_OUTLOOKTABCTRL        400
#define IDD_OUTLOOK_CMD                 500
#define IDD_OUTLOOK_CMD_BUTTON_UP       501
#define IDD_OUTLOOK_CMD_BUTTON_DOWN     502
#define IDD_OUTLOOK_CMD_BUTTON_RESET    503
#define IDD_OUTLOOK_CMD_LIST1           504
#define IDC_CHECK1                      600
#define IDC_CHECK2                      601
#define IDC_CHECK3                      602
#define IDC_RADIO1                      700
#define IDC_RADIO2                      701
#define IDC_RADIO3                      702
#define IDC_RADIO4                      703
#define IDC_RADIO5                      704
#define IDC_RADIO6                      705
#define IDC_RADIO7                      706
#define IDC_RADIO8                      707
#define IDC_RADIO9                      708
#define IDC_RADIO10                     709
#define IDC_RADIO11                     710
#define IDC_RADIO12                     711
#define IDC_BUTTON1                     800
#define ID_POPUP_OUTLOOKTABCTRL_POP     32000
#define ID_POPUP_OUTLOOKTABCTRL_PUSH    32001
#define ID_POPUP_OUTLOOKTABCTRL_MANAGE  32002
#define ID_TESTDLG                      32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
