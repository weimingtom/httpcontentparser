/////////////////////////////////////////////////////////////////////////////
#pragma once
/////////////////////////////////////////////////////////////////////////////
#include "OutlookTabCtrl\OutlookTabCtrlEx.h"
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// 
enum CUSTOMSTYLE
{	CUSTOMSTYLE_NONE,
	CUSTOMSTYLE_1,
	CUSTOMSTYLE_2
};
// 
class OutlookTabCtrlExCustom : public OutlookTabCtrlEx
{public:
	OutlookTabCtrlExCustom()
	{	m_Style = CUSTOMSTYLE_NONE;
	}

public:
	void SetCustomStyle(CUSTOMSTYLE style)
	{	m_Style = style;
			// 
		if(m_pToolTip!=NULL && m_pToolTip->m_hWnd!=NULL)
			if(m_Style!=CUSTOMSTYLE_NONE)
			{	m_pToolTip->SetTipBkColor(RGB(228,225,220));
				m_pToolTip->SetTipTextColor(RGB(50,50,50));
			}
			else
			{	m_pToolTip->SetTipBkColor(::GetSysColor(COLOR_INFOBK));
				m_pToolTip->SetTipTextColor(::GetSysColor(COLOR_INFOTEXT));
			}
	}
	CUSTOMSTYLE GetCustomStyle() const
	{	return m_Style;
	}

private:
	CUSTOMSTYLE m_Style;
	CBitmap m_bmpBackground;

private:
	virtual COLORREF GetBorderColor()
	{	if(m_Style==CUSTOMSTYLE_1) return RGB(77,115,61);
		else if(m_Style==CUSTOMSTYLE_2) return RGB(29,112,224);
		return OutlookTabCtrlEx::GetBorderColor();
	}
	virtual COLORREF GetSeparationLineColor()
	{	if(m_Style==CUSTOMSTYLE_1) return RGB(77,115,61);
		else if(m_Style==CUSTOMSTYLE_2) return RGB(29,112,224);
		return OutlookTabCtrlEx::GetSeparationLineColor();
	}
	virtual COLORREF GetIconShadowColor()
	{	if(m_Style==CUSTOMSTYLE_1) return RGB(77,115,61);
		else if(m_Style==CUSTOMSTYLE_2) return RGB(29,112,224);
		return OutlookTabCtrlEx::GetIconShadowColor();
	}
	virtual COLORREF GetMenuButtonImageColor()
	{	if(m_Style==CUSTOMSTYLE_1) return RGB(77,115,61);
		else if(m_Style==CUSTOMSTYLE_2) return RGB(72,36,0);
		return OutlookTabCtrlEx::GetMenuButtonImageColor();
	}
		// 
	virtual COLORREF GetCaptionColor()
	{	if(m_Style==CUSTOMSTYLE_2) return RGB(121,80,72);
		return OutlookTabCtrlEx::GetCaptionColor();
	}
	virtual COLORREF GetCaptionTextColor()
	{	if(m_Style==CUSTOMSTYLE_1) return RGB(255,255,255);
		else if(m_Style==CUSTOMSTYLE_2) return RGB(208,183,179);
		return OutlookTabCtrlEx::GetCaptionTextColor();
	}
		// 
	virtual int GetButtonHeight()
	{	return OutlookTabCtrlEx::GetButtonHeight() - (m_Style!=CUSTOMSTYLE_NONE ? 6 : 0);
	}
		// 
	virtual COLORREF GetTabTextColor(ItemState const *state)
	{	if(m_Style==CUSTOMSTYLE_1) return (state->bHighlighted==false ? RGB(60,60,60) : RGB(0,0,0));
		else if(m_Style==CUSTOMSTYLE_2) return RGB(72,36,0);
		return OutlookTabCtrlEx::GetTabTextColor(state);
	}
	virtual COLORREF GetDisabledTabTextColor(ItemState const *state)
	{	if(m_Style==CUSTOMSTYLE_1) return RGB(128,128,128);
		else if(m_Style==CUSTOMSTYLE_2) return RGB(15,58,117);
		return OutlookTabCtrlEx::GetDisabledTabTextColor(state);
	}
   	// 
	void DrawGradient(CDC *pDC, CRect const *rc, COLORREF clrTop, COLORREF clrBottom)
	{	GRADIENT_RECT gRect = {0,1};
		TRIVERTEX vert[2] = 
		{	{rc->left,rc->top,(COLOR16)(GetRValue(clrTop)<<8),(COLOR16)(GetGValue(clrTop)<<8),(COLOR16)(GetBValue(clrTop)<<8),0},
			{rc->right,rc->bottom,(COLOR16)(GetRValue(clrBottom)<<8),(COLOR16)(GetGValue(clrBottom)<<8),(COLOR16)(GetBValue(clrBottom)<<8),0}
		};
		::GradientFill(pDC->m_hDC,vert,2,&gRect,1,GRADIENT_FILL_RECT_V);
	}
		// 
	void DrawPicture(CDC *pDC, CRect const *rc, CBitmap *pBitmap)
	{	CDC dc;
		if(dc.CreateCompatibleDC(pDC)==0) return;
		dc.SelectObject(pBitmap);
			// 
		CRect rcTabs, rcButtons;
		GetTabsRect(&rcTabs);
		GetButtonsRect(&rcButtons);
		CPoint ptLeftTop(rcTabs.left,min(rcTabs.top,rcButtons.top));
			// 
		BITMAP bmpinfo;
		::GetObject(pBitmap->m_hObject,sizeof(bmpinfo),&bmpinfo);
		int x,y, x_pic,y_pic, width,height;
			// 
		for(y=rc->top; y<rc->bottom; )
		{	y_pic = (y-ptLeftTop.y) % bmpinfo.bmHeight;
			height = min(bmpinfo.bmHeight-y_pic,rc->bottom-y);
				// 				
			for(x=rc->left; x<rc->right; )
			{	x_pic = (x-ptLeftTop.x) % bmpinfo.bmWidth;
				width = min(bmpinfo.bmWidth-x_pic,rc->right-x);
					// 
				pDC->BitBlt(x,y,width,height,&dc,x_pic,y_pic,SRCCOPY);
				x += width;
			}
			y += height;
		}
	}
		// 
	virtual void DrawBackground(CDC *pDC, ItemState const *state, CRect const *pRect)
	{	if(m_Style!=CUSTOMSTYLE_NONE)
		{	bool bSelectLight=false, bSelectDark=false;
			AssignHighlightStateOfItem(state,&bSelectLight,&bSelectDark);
				// 
			if(m_Style==CUSTOMSTYLE_1)
			{	if(bSelectLight==true)
					DrawGradient(pDC,pRect,RGB(248,230,182),RGB(241,189,111));
				else if(bSelectDark==true)
					DrawGradient(pDC,pRect,RGB(247,227,171),RGB(225,142,24));
				else
					DrawGradient(pDC,pRect,RGB(255,255,255),RGB(213,209,201));
			}
			else	// CUSTOMSTYLE_2.
			{	if(bSelectLight==true)
					DrawGradient(pDC,pRect,RGB(207,225,251),RGB(116,163,228));
				else if(bSelectDark==true)
					DrawGradient(pDC,pRect,RGB(167,199,248),RGB(97,151,224));
				else
					DrawPicture(pDC,pRect,&m_bmpBackground);
			}
		}
		else
			OutlookTabCtrlEx::DrawBackground(pDC,state,pRect);
	}
		// 
	virtual void DrawSplitter(CDC *pDC, CRect const *pRect)
	{	if(m_Style==CUSTOMSTYLE_1)
		{	DrawGradient(pDC,pRect,RGB(127,127,127),RGB(71,71,71));
			if(IsActiveSplitter()==true) DrawSplitterDots(pDC,pRect,7,RGB(10,10,10),RGB(230,230,230));
		}
		else if(m_Style==CUSTOMSTYLE_2)
		{	DrawGradient(pDC,pRect,RGB(145,96,87),RGB(121,80,72));
			if(IsActiveSplitter()==true) DrawSplitterDots(pDC,pRect,7,RGB(51,33,30),RGB(208,183,179));
		}
		else
			OutlookTabCtrlEx::DrawSplitter(pDC,pRect);
	}
		// 
	virtual bool CanSelectItem(HTAB hItem)
	{	CString text;
		GetItemText(hItem,&text);
		if(text=="Calendar")
		{	::MessageBox(m_hWnd,"You can not select this item.","OutlookTabCtrlExCustom",MB_OK);
			return false;
		}
		return true;
	}
	virtual void SelectItemNotify(HTAB hItem)
	{	CString text;
		GetItemText(hItem,&text);
		text = ("You have been selected item: \"" + text) + '\"';
		::MessageBox(m_hWnd,text,"OutlookTabCtrlExCustom",MB_OK);
	}

private:
	DECLARE_MESSAGE_MAP()
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// 
class TabDialog : public CDialog
{private:
	DECLARE_MESSAGE_MAP()
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnBnClickedButton1();
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// 
class TestDlg : public CDialog
{private:
	OutlookTabCtrlExCustom m_OutlookTabCtrlEx;
	CListCtrl m_List1, m_List2, m_List3;
	CTreeCtrl m_Tree1, m_Tree2, m_Tree3;
	CEdit m_Edit1, m_Edit2;
	TabDialog m_Dlg1;

protected:
	DECLARE_MESSAGE_MAP()
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedCheck1();
	afx_msg void OnBnClickedCheck2();
	afx_msg void OnBnClickedCheck3();
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedRadio3();
	afx_msg void OnBnClickedRadio4();
	afx_msg void OnBnClickedRadio5();
	afx_msg void OnBnClickedRadio6();
	afx_msg void OnBnClickedRadio7();
	afx_msg void OnBnClickedRadio8();
	afx_msg void OnBnClickedRadio9();
	afx_msg void OnBnClickedRadio10();
	afx_msg void OnBnClickedRadio11();
	afx_msg void OnBnClickedRadio12();
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////








