// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Project.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_UPDATE_COMMAND_UI(ID_TESTDLG, OnUpdateTestdlg)
	ON_COMMAND(ID_TESTDLG, OnTestdlg)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// 
CMainFrame::CMainFrame()
{
}
CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("Failed to create view window\n");
		return -1;
	}

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);






	if(m_ContainerBar.Create(CRect(0,0,250,250),this,2000)==false) return -1;
	if(m_OutlookTabCtrlEx.Create(&m_ContainerBar,WS_CHILD | WS_VISIBLE | WS_BORDER,CRect(0,0,0,0),2001)==false) return -1;
	m_ContainerBar.SetChildWindow(&m_OutlookTabCtrlEx);
		// 
	CImageList imagelistBig, imagelistSmall;
	CBitmap bmpBig, bmpSmall;
		// 
	imagelistBig.Create(24,24,ILC_COLOR24 | ILC_MASK,4,0);
	bmpBig.LoadBitmap(IDB_BITMAP1);
	imagelistBig.Add(&bmpBig,RGB(255,0,255));
		// 
	imagelistSmall.Create(16,16,ILC_COLOR24 | ILC_MASK,4,0);
	bmpSmall.LoadBitmap(IDB_BITMAP2);
	imagelistSmall.Add(&bmpSmall,RGB(255,0,255));
		// 
	m_OutlookTabCtrlEx.SetImageLists(&imagelistBig,&imagelistSmall,NULL,NULL);
		// 
	if(m_List1.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,2002)==0 ||
		m_List2.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,2003)==0 ||
		m_List3.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,2004)==0 ||
		m_List4.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,2005)==0 ||
		m_List5.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,2006)==0 ||
		m_List6.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,2007)==0 ||
		m_List7.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,2008)==0 ||
		m_List8.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,2009)==0)
		return -1;
		// 
	m_List1.InsertColumn(0,"Mail",LVCFMT_LEFT,100);
	m_List2.InsertColumn(0,"Calendar",LVCFMT_LEFT,100);
	m_List3.InsertColumn(0,"Contacts",LVCFMT_LEFT,100);
	m_List4.InsertColumn(0,"Tasks",LVCFMT_LEFT,100);
	m_List5.InsertColumn(0,"Business Affairs",LVCFMT_LEFT,100);
	m_List6.InsertColumn(0,"Notes",LVCFMT_LEFT,100);
	m_List7.InsertColumn(0,"Folder List",LVCFMT_LEFT,100);
	m_List8.InsertColumn(0,"Shortcuts",LVCFMT_LEFT,100);
		// 
	if(m_OutlookTabCtrlEx.Add(&m_List1,"Mail",0,0)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_List2,"Calendar",1,1)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_List3,"Contacts",2,2)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_List4,"Tasks",3,3)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_List5,"Business Affairs",-1,-1)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_List6,"Notes",4,4)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_List7,"Folder List",5,5)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_List8,"Shortcuts",6,6)==NULL)
		return -1;
		// 
	if(m_OutlookTabCtrlEx.LoadState(AfxGetApp(),"OutlookTabCtrl","TabsState")==false)
		m_OutlookTabCtrlEx.PushItem();
		// 
	m_OutlookTabCtrlEx.Update();

	

	m_TestDlg.Create(IDD_TESTDLG,this);
	m_TestDlg.CenterWindow(this);
	m_TestDlg.ShowWindow(SW_SHOW);



	return 0;
}

void CMainFrame::OnDestroy()
{	m_OutlookTabCtrlEx.SaveState(AfxGetApp(),"OutlookTabCtrl","TabsState");
		// 
	CFrameWnd::OnDestroy();
}


void CMainFrame::OnUpdateTestdlg(CCmdUI *pCmdUI)
{	pCmdUI->Enable(!m_TestDlg.IsWindowVisible());
}
void CMainFrame::OnTestdlg()
{	m_TestDlg.ShowWindow(SW_SHOW);
}







BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	// forward focus to the view window
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG









