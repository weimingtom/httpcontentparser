// ChildView.h : interface of the CChildView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDVIEW_H__904D87CB_AF66_42AC_B993_C162EBBC9D8A__INCLUDED_)
#define AFX_CHILDVIEW_H__904D87CB_AF66_42AC_B993_C162EBBC9D8A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


/////////////////////////////////////////////////////////////////////////////
// CChildView window

class CChildView : public CWnd
{public:
	CChildView();
	virtual ~CChildView();

	DECLARE_DYNCREATE(CChildView)

private:
	//OutlookTabCtrlEx m_OutlookTabCtrlEx;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CChildView)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDVIEW_H__904D87CB_AF66_42AC_B993_C162EBBC9D8A__INCLUDED_)
