//==========================================================
// Author: Borodenko Oleg
// 02/09/2007 <oktamail@gmail.com>
//==========================================================
// 
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "ContainerBar.h"
/////////////////////////////////////////////////////////////////////////////
#include "afxpriv.h"
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(ContainerBar, CWnd)
	ON_MESSAGE(WM_SIZEPARENT, OnSizeParent)
	ON_MESSAGE(WM_EXITSIZEMOVE, OnExitSizeMove)
	ON_WM_NCHITTEST()
	ON_WM_SIZE()
	ON_WM_SIZING()
	ON_WM_GETMINMAXINFO()
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// 
ContainerBar::ContainerBar()
{	m_pWndChild = NULL;
}
/////////////////////////////////////////////////////////////////////////////
// 
bool ContainerBar::Create(const RECT& rect, CWnd* pParentWnd, UINT nID)
{	m_iWidth = rect.right - rect.left;
	CString wndclass = ::AfxRegisterWndClass(CS_HREDRAW | CS_VREDRAW,::LoadCursor(NULL,IDC_ARROW),(HBRUSH)(COLOR_BTNFACE+1),0);
	return CWnd::Create(wndclass,"",WS_VISIBLE | WS_CHILD | WS_CLIPCHILDREN,rect,pParentWnd,nID)!=0;
}
/////////////////////////////////////////////////////////////////////////////
// 
void ContainerBar::SetChildWindow(CWnd *pWndChild)
{	m_pWndChild = pWndChild;
}
/////////////////////////////////////////////////////////////////////////////
#define RIGHT_BORDER 3
/////////////////////////////////////////////////////////////////////////////
// 
LRESULT ContainerBar::OnSizeParent(WPARAM /*wParam*/, LPARAM lParam)
{	AFX_SIZEPARENTPARAMS* lpLayout = (AFX_SIZEPARENTPARAMS*)lParam;
		// 
	MoveWindow(lpLayout->rect.left,lpLayout->rect.top,m_iWidth,lpLayout->rect.bottom-lpLayout->rect.top);
		// 
	lpLayout->rect.left += m_iWidth;
	lpLayout->sizeTotal.cx += m_iWidth;
		// 
	return 0;
}
// 
LRESULT ContainerBar::OnExitSizeMove(WPARAM /*wParam*/, LPARAM /*lParam*/)
{	SetWindowPos(&wndBottom,0,0,0,0,SWP_NOMOVE | SWP_NOSIZE);
	return 1;
}
/////////////////////////////////////////////////////////////////////////////
// 
#if _MSC_VER <= 1310	// Microsoft Visual C++ .NET 2003 and below.
	UINT ContainerBar::OnNcHitTest(CPoint point)
#else
	LRESULT ContainerBar::OnNcHitTest(CPoint point)
#endif
{	CRect rc;
	GetWindowRect(&rc);
	rc.left = rc.right - RIGHT_BORDER;
	if(rc.PtInRect(point)!=0) return HTRIGHT;
		// 
	return CWnd::OnNcHitTest(point);
}
/////////////////////////////////////////////////////////////////////////////
// 
void ContainerBar::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{	lpMMI->ptMinTrackSize.x = 30;
	CWnd::OnGetMinMaxInfo(lpMMI);
}
/////////////////////////////////////////////////////////////////////////////
// 
void ContainerBar::OnSizing(UINT fwSide, LPRECT pRect)
{	if(fwSide==WMSZ_RIGHT) 
	{	m_iWidth = pRect->right - pRect->left;
		((CFrameWnd *)GetParent())->RecalcLayout();
	}
		// 
	CWnd::OnSizing(fwSide, pRect);
}
/////////////////////////////////////////////////////////////////////////////
// 
void ContainerBar::OnSize(UINT nType, int cx, int cy)
{	CWnd::OnSize(nType, cx, cy);
		// 
	if(m_pWndChild!=NULL)
	{	CRect rc;
		GetClientRect(&rc);
		rc.top ++;
		rc.right -= RIGHT_BORDER;
		m_pWndChild->MoveWindow(&rc);
	}
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////








