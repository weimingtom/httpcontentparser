//==========================================================
// Author: Borodenko Oleg
// 02/09/2007 <oktamail@gmail.com>
//==========================================================
// 
#pragma once
/////////////////////////////////////////////////////////////////////////////
//
class ContainerBar : public CWnd
{public:
	ContainerBar();

public:
	bool Create(const RECT& rect, CWnd* pParentWnd, UINT nID);
	void SetChildWindow(CWnd *pWndChild);

private:
	CWnd *m_pWndChild;
	int m_iWidth;

protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	LRESULT OnSizeParent(WPARAM, LPARAM lParam);
	LRESULT OnExitSizeMove(WPARAM, LPARAM lParam);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	#if _MSC_VER <= 1310	// Microsoft Visual C++ .NET 2003 and below.
		afx_msg UINT OnNcHitTest(CPoint point);
	#else
		afx_msg LRESULT OnNcHitTest(CPoint point);
	#endif
};
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////




