/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "resource.h"
/////////////////////////////////////////////////////////////////////////////
#include "TestDlg.h"
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(OutlookTabCtrlExCustom, OutlookTabCtrlEx)
	ON_WM_CREATE()
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// 
int OutlookTabCtrlExCustom::OnCreate(LPCREATESTRUCT lpCreateStruct)
{	if(OutlookTabCtrlEx::OnCreate(lpCreateStruct)==-1) return -1;
		// 
	if(m_bmpBackground.LoadBitmap(IDB_BACKGROUND)==0) return -1;
		// 
	return 0;
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(TabDialog, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// 
void TabDialog::OnBnClickedButton1()
{	::MessageBox(m_hWnd,":-)","TabDialog",MB_OK);
}
// 
void TabDialog::OnCancel()
{	//CDialog::OnCancel();
}
// 
void TabDialog::OnOK()
{	//CDialog::OnOK();
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(TestDlg, CDialog)
	ON_WM_DESTROY()
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_CHECK1, OnBnClickedCheck1)
	ON_BN_CLICKED(IDC_CHECK2, OnBnClickedCheck2)
	ON_BN_CLICKED(IDC_CHECK3, OnBnClickedCheck3)
	ON_BN_CLICKED(IDC_RADIO1, OnBnClickedRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnBnClickedRadio2)
	ON_BN_CLICKED(IDC_RADIO3, OnBnClickedRadio3)
	ON_BN_CLICKED(IDC_RADIO4, OnBnClickedRadio4)
	ON_BN_CLICKED(IDC_RADIO5, OnBnClickedRadio5)
	ON_BN_CLICKED(IDC_RADIO6, OnBnClickedRadio6)
	ON_BN_CLICKED(IDC_RADIO7, OnBnClickedRadio7)
	ON_BN_CLICKED(IDC_RADIO8, OnBnClickedRadio8)
	ON_BN_CLICKED(IDC_RADIO9, OnBnClickedRadio9)
	ON_BN_CLICKED(IDC_RADIO10, OnBnClickedRadio10)
	ON_BN_CLICKED(IDC_RADIO11, OnBnClickedRadio11)
	ON_BN_CLICKED(IDC_RADIO12, OnBnClickedRadio12)
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// 
int TestDlg::OnCreate(LPCREATESTRUCT lpCreateStruct)
{	if(CDialog::OnCreate(lpCreateStruct)==-1) return -1;
		// 
	if(m_OutlookTabCtrlEx.Create(this,WS_CHILD | WS_VISIBLE | WS_BORDER,CRect(5,5,240,440),3001)==false) return -1;
		// 
		// 
	if(m_List1.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,3002)==0 ||
		m_List2.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,3003)==0 ||
		m_List3.Create(WS_CHILD | WS_CLIPCHILDREN | LVS_REPORT,CRect(0,0,0,0),&m_OutlookTabCtrlEx,3004)==0)
		return -1;
		// 
	if(m_Tree1.Create(WS_VISIBLE | WS_CHILD | TVS_HASBUTTONS | TVS_LINESATROOT | TVS_HASLINES,CRect(0,0,0,0),&m_OutlookTabCtrlEx,3005)==0 ||
		m_Tree2.Create(WS_VISIBLE | WS_CHILD | TVS_HASBUTTONS | TVS_LINESATROOT | TVS_HASLINES,CRect(0,0,0,0),&m_OutlookTabCtrlEx,3006)==0 ||
		m_Tree3.Create(WS_VISIBLE | WS_CHILD | TVS_HASBUTTONS | TVS_LINESATROOT | TVS_HASLINES,CRect(0,0,0,0),&m_OutlookTabCtrlEx,3007)==0)
		return -1;
		// 
	if(m_Edit1.Create(ES_MULTILINE | WS_CHILD | WS_VISIBLE,CRect(0,0,0,0),&m_OutlookTabCtrlEx,3008)==0 ||
		m_Edit2.Create(ES_MULTILINE | WS_CHILD | WS_VISIBLE,CRect(0,0,0,0),&m_OutlookTabCtrlEx,3009)==0)
		return -1;
		// 
	if(m_Dlg1.Create(IDD_DIALOG,&m_OutlookTabCtrlEx)==0) return -1;	// create as modeless dialog box.
	m_Dlg1.SetDlgCtrlID(3010);		// set unique id - important for dialog box.
		// 
	if(m_OutlookTabCtrlEx.Add(&m_Tree1,"Mail",0,0)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_List1,"Calendar",1,1)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_Dlg1,"Modeless Dialog Box",-1,-1)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_Edit1,"Contacts",2,2)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_Tree2,"Tasks",3,3)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_List2,"Business Affairs",-1,-1)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_Edit2,"Notes",4,4)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_List3,"Folder List",5,5)==NULL ||
		m_OutlookTabCtrlEx.Add(&m_Tree3,"Shortcuts",6,6)==NULL)
		return -1;
		// 
	return 0;
}
/////////////////////////////////////////////////////////////////////////////
// 
BOOL TestDlg::OnInitDialog()
{	CDialog::OnInitDialog();
		// 
		// 
	m_List1.InsertColumn(0,"Calendar",LVCFMT_LEFT,100);
	m_List2.InsertColumn(0,"Business Affairs",LVCFMT_LEFT,100);
	m_List3.InsertColumn(0,"Folder List",LVCFMT_LEFT,100);
		// 
	m_Tree1.InsertItem("Mail");
	m_Tree2.InsertItem("Tasks");
	m_Tree3.InsertItem("Shortcuts");
		// 
	m_Edit1.SetWindowText("Contacts");
	m_Edit2.SetWindowText("Notes");
		// 
		// 
	CImageList imagelistBig, imagelistSmall, imagelistDisabledBig, imagelistDisabledSmall;
	CBitmap bmpBig, bmpSmall, bmpDisabledBig, bmpDisabledSmall;
		// 
	imagelistBig.Create(24,24,ILC_COLOR24 | ILC_MASK,4,0);
	bmpBig.LoadBitmap(IDB_BITMAP1);
	imagelistBig.Add(&bmpBig,RGB(255,0,255));
		// 
	imagelistSmall.Create(16,16,ILC_COLOR24 | ILC_MASK,4,0);
	bmpSmall.LoadBitmap(IDB_BITMAP2);
	imagelistSmall.Add(&bmpSmall,RGB(255,0,255));
		// 
	imagelistDisabledBig.Create(24,24,ILC_COLOR24 | ILC_MASK,4,0);
	bmpDisabledBig.LoadBitmap(IDB_BITMAP3);
	imagelistDisabledBig.Add(&bmpDisabledBig,RGB(255,0,255));
		// 
	imagelistDisabledSmall.Create(16,16,ILC_COLOR24 | ILC_MASK,4,0);
	bmpDisabledSmall.LoadBitmap(IDB_BITMAP4);
	imagelistDisabledSmall.Add(&bmpDisabledSmall,RGB(255,0,255));
		// 
	m_OutlookTabCtrlEx.SetImageLists(&imagelistBig,&imagelistSmall,&imagelistDisabledBig,&imagelistDisabledSmall);
		// 
	if(m_OutlookTabCtrlEx.LoadState(AfxGetApp(),"OutlookTabCtrl_TestDlg","TabsState")==false)
	{	m_OutlookTabCtrlEx.PushItem();
		m_OutlookTabCtrlEx.PushItem();
		m_OutlookTabCtrlEx.PushItem();
	}
		// 
		// 
	m_OutlookTabCtrlEx.Disable(m_OutlookTabCtrlEx.GetItem(3),true);
		// 
		// 
		// 
	CButton *pbtStyleCustom1 = (CButton *)GetDlgItem(IDC_RADIO2);
	CButton *pbtLayout1 = (CButton *)GetDlgItem(IDC_RADIO7);
	CButton *pbtCaptionTop = (CButton *)GetDlgItem(IDC_RADIO5);
	CButton *pbtAlignRight = (CButton *)GetDlgItem(IDC_RADIO11);
	CButton *pbtActiveSplitter = (CButton *)GetDlgItem(IDC_CHECK1);
	CButton *pbtShowMenuButton = (CButton *)GetDlgItem(IDC_CHECK2);
	CButton *pbtHideEmptyButtonsBar = (CButton *)GetDlgItem(IDC_CHECK3);
		// 
	m_OutlookTabCtrlEx.SetCustomStyle(CUSTOMSTYLE_1);
	pbtStyleCustom1->SetCheck(1);
		// 
	m_OutlookTabCtrlEx.SetLayout(OUTLOOKTABCTRL_LAYOUT_1);
	pbtLayout1->SetCheck(1);
		// 
	m_OutlookTabCtrlEx.ShowCaption(true);
	m_OutlookTabCtrlEx.SetCaptionAlign(OUTLOOKTABCTRL_CAPTIONALIGN_TOP);
	pbtCaptionTop->SetCheck(1);
		// 
	m_OutlookTabCtrlEx.SetButtonsAlign(OUTLOOKTABCTRL_BUTTONSALIGN_RIGHT);
	pbtAlignRight->SetCheck(1);
		// 
	m_OutlookTabCtrlEx.ActiveSplitter(true);
	pbtActiveSplitter->SetCheck(1);
	m_OutlookTabCtrlEx.ShowMenuButton(false);
	pbtShowMenuButton->SetCheck(0);
	m_OutlookTabCtrlEx.HideEmptyButtonsBar(true);
	pbtHideEmptyButtonsBar->SetCheck(1);
		// 
	m_OutlookTabCtrlEx.Update();
		// 
		// 
	return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
// 
void TestDlg::OnDestroy()
{	m_OutlookTabCtrlEx.SaveState(AfxGetApp(),"OutlookTabCtrl_TestDlg","TabsState");
		// 
	CDialog::OnDestroy();
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// Style - default.
// 
void TestDlg::OnBnClickedRadio1()
{	m_OutlookTabCtrlEx.SetCustomStyle(CUSTOMSTYLE_NONE);
	m_OutlookTabCtrlEx.Update();
	m_OutlookTabCtrlEx.SetWindowPos(NULL, 0,0,0,0, SWP_NOZORDER | SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED);	// border update.
}
/////////////////////////////////////////////////////////////////////////////
// Style - custom 1.
// 
void TestDlg::OnBnClickedRadio2()
{	m_OutlookTabCtrlEx.SetCustomStyle(CUSTOMSTYLE_1);
	m_OutlookTabCtrlEx.Update();
	m_OutlookTabCtrlEx.SetWindowPos(NULL, 0,0,0,0, SWP_NOZORDER | SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED);	// border update.
}
/////////////////////////////////////////////////////////////////////////////
// Style - custom 2.
// 
void TestDlg::OnBnClickedRadio3()
{	m_OutlookTabCtrlEx.SetCustomStyle(CUSTOMSTYLE_2);
	m_OutlookTabCtrlEx.Update();
	m_OutlookTabCtrlEx.SetWindowPos(NULL, 0,0,0,0, SWP_NOZORDER | SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED);	// border update.
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// Caption - none.
// 
void TestDlg::OnBnClickedRadio4()
{	m_OutlookTabCtrlEx.ShowCaption(false);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
// Caption - top.
// 
void TestDlg::OnBnClickedRadio5()
{	m_OutlookTabCtrlEx.ShowCaption(true);
	m_OutlookTabCtrlEx.SetCaptionAlign(OUTLOOKTABCTRL_CAPTIONALIGN_TOP);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
// Caption - bottom.
// 
void TestDlg::OnBnClickedRadio6()
{	m_OutlookTabCtrlEx.ShowCaption(true);
	m_OutlookTabCtrlEx.SetCaptionAlign(OUTLOOKTABCTRL_CAPTIONALIGN_BOTTOM);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// Layout - controls|splitter|tabs|buttons.
// 
void TestDlg::OnBnClickedRadio7()
{	m_OutlookTabCtrlEx.SetLayout(OUTLOOKTABCTRL_LAYOUT_1);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
// Layout - controls|splitter|buttons|tabs.
// 
void TestDlg::OnBnClickedRadio8()
{	m_OutlookTabCtrlEx.SetLayout(OUTLOOKTABCTRL_LAYOUT_2);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
// Layout - buttons|tabs|splitter|controls.
// 
void TestDlg::OnBnClickedRadio9()
{	m_OutlookTabCtrlEx.SetLayout(OUTLOOKTABCTRL_LAYOUT_3);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
// Layout - tabs|buttons|splitter|controls.
// 
void TestDlg::OnBnClickedRadio10()
{	m_OutlookTabCtrlEx.SetLayout(OUTLOOKTABCTRL_LAYOUT_4);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// Buttons align - right.
// 
void TestDlg::OnBnClickedRadio11()
{	m_OutlookTabCtrlEx.SetButtonsAlign(OUTLOOKTABCTRL_BUTTONSALIGN_RIGHT);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
// Buttons align - left.
// 
void TestDlg::OnBnClickedRadio12()
{	m_OutlookTabCtrlEx.SetButtonsAlign(OUTLOOKTABCTRL_BUTTONSALIGN_LEFT);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// Active splitter.
// 
void TestDlg::OnBnClickedCheck1()
{	CButton *pbtActiveSplitter = (CButton *)GetDlgItem(IDC_CHECK1);
	m_OutlookTabCtrlEx.ActiveSplitter(pbtActiveSplitter->GetCheck()==1 ? true : false);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
// Show menu button.
// 
void TestDlg::OnBnClickedCheck2()
{	CButton *pbtShowMenuButton = (CButton *)GetDlgItem(IDC_CHECK2);
	CButton *pbtHideEmptyButtonsBar = (CButton *)GetDlgItem(IDC_CHECK3);
		// 
	bool bShowMenuButton = pbtShowMenuButton->GetCheck()==1;
	m_OutlookTabCtrlEx.ShowMenuButton(bShowMenuButton);
	if(bShowMenuButton==true)
		pbtHideEmptyButtonsBar->ModifyStyle(0,WS_DISABLED);
	else
		pbtHideEmptyButtonsBar->ModifyStyle(WS_DISABLED,0);
	pbtHideEmptyButtonsBar->Invalidate(FALSE);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
// Hide empty buttons bar.
// 
void TestDlg::OnBnClickedCheck3()
{	CButton *pbtHideEmptyButtonsBar = (CButton *)GetDlgItem(IDC_CHECK3);
	m_OutlookTabCtrlEx.HideEmptyButtonsBar(pbtHideEmptyButtonsBar->GetCheck()==1 ? true : false);
	m_OutlookTabCtrlEx.Update();
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////



















