#if !defined(AFX_MAINFRM_H__821F164C_F183_4981_880F_1B5E4A02A66E__INCLUDED_)
#define AFX_MAINFRM_H__821F164C_F183_4981_880F_1B5E4A02A66E__INCLUDED_


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "ChildView.h"
#include "TestDlg.h"
#include "ContainerBar\ContainerBar.h"
#include "OutlookTabCtrl\OutlookTabCtrlEx.h"


class CMainFrame : public CFrameWnd
{public:
	CMainFrame();
	virtual ~CMainFrame();

protected: 
	DECLARE_DYNAMIC(CMainFrame)

public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CChildView    m_wndView;

	ContainerBar m_ContainerBar;
	OutlookTabCtrlEx m_OutlookTabCtrlEx;
	CListCtrl m_List1,m_List2,m_List3,m_List4,m_List5,m_List6,m_List7,m_List8;

	TestDlg m_TestDlg;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	afx_msg void OnUpdateTestdlg(CCmdUI *pCmdUI);
	afx_msg void OnTestdlg();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__821F164C_F183_4981_880F_1B5E4A02A66E__INCLUDED_)
