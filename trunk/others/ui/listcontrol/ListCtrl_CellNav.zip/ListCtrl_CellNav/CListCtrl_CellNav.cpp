#include "stdafx.h"

#include "CListCtrl_CellNav.h"
#include "CListCtrl_DataModel.h"

BEGIN_MESSAGE_MAP(CListCtrl_CellNav, CListCtrl)
	ON_NOTIFY_REFLECT(NM_CUSTOMDRAW, OnCustomDraw)
	ON_WM_KEYDOWN()		// OnKeydown
	ON_WM_LBUTTONDOWN()	// OnLButtonDown(UINT nFlags, CPoint point)
	ON_WM_RBUTTONDOWN()	// OnRButtonDown(UINT nFlags, CPoint point)
	ON_WM_CHAR()		// OnChar
END_MESSAGE_MAP()

void CListCtrl_CellNav::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// Catch event before the parent listctrl gets it to avoid extra scrolling
	//	- OBS! This can also prevent the key-events to reach LVN_KEYDOWN handlers
	switch(nChar)
	{
		case VK_RIGHT:	MoveFocusCell(true);	return;	// Do not allow scroll
		case VK_LEFT:	MoveFocusCell(false);	return;	// Do not allow scroll
		case 0x41:		// CTRL+A (Select all rows)
		{
			if (GetKeyState(VK_CONTROL) < 0)
			{
				if (!(GetStyle() & LVS_SINGLESEL))
					SetItemState(-1, LVIS_SELECTED, LVIS_SELECTED);
			}
			break;
		}
	}
	CListCtrl::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CListCtrl_CellNav::MoveFocusCell(bool right)
{
	if (GetItemCount()<=0)
	{
		m_FocusCell = -1;	// Entire row selected
		return;
	}

	if (m_FocusCell == -1)
	{
		// Entire row already selected
		if (right)
		{
			// Change to the first column in the current order
			m_FocusCell = GetHeaderCtrl()->OrderToIndex(0);
		}
	}
	else
	{
		// Convert focus-cell to order index
		int nOrderIndex = -1;
		for(int i = 0; i < GetHeaderCtrl()->GetItemCount(); ++i)
		{
			int nCol = GetHeaderCtrl()->OrderToIndex(i);
			if (nCol == m_FocusCell)
			{
				nOrderIndex = i;
				break;
			}
		}

		// Move to the following column
		if (right)
			nOrderIndex++;
		else
			nOrderIndex--;

		// Convert order-index to focus cell
		if (nOrderIndex >= 0 && nOrderIndex < GetHeaderCtrl()->GetItemCount())
		{
			m_FocusCell = GetHeaderCtrl()->OrderToIndex(nOrderIndex);
		}
		else if (!right)
			m_FocusCell = -1;	// Entire row selection
	}

	// Ensure the column is visible
	if (m_FocusCell >= 0)
	{
		VERIFY( EnsureColumnVisible(m_FocusCell, false) );
	}

	UpdateFocusCell(m_FocusCell);
}

// Force redraw of focus row, so the focus cell becomes visible
void CListCtrl_CellNav::UpdateFocusCell(int nCol)
{
	m_FocusCell = nCol;	// Update focus cell before starting re-draw
	int nFocusRow = GetNextItem(-1, LVNI_FOCUSED);
	if (nFocusRow >= 0)
	{
		CRect itemRect;
		VERIFY( GetItemRect(nFocusRow, itemRect, LVIR_BOUNDS) );
		InvalidateRect(itemRect);
		UpdateWindow();
	}
}

// http://www.codeguru.com/cpp/controls/listview/columns/article.php/c931/
BOOL CListCtrl_CellNav::EnsureColumnVisible(int nCol, bool bPartialOK)
{
	if (nCol < 0 || nCol >= GetHeaderCtrl()->GetItemCount())
		return FALSE;

	CRect rcHeader;
	if (GetHeaderCtrl()->GetItemRect(nCol, rcHeader)==FALSE)
		return FALSE;

	CRect rcClient;
	GetClientRect(&rcClient);

	int nOffset = GetScrollPos(SB_HORZ);

	if(bPartialOK)
	{
		if((rcHeader.left - nOffset < rcClient.right) && (rcHeader.right - nOffset > 0))
		{
			return TRUE;
		}
	}

	int nScrollX = 0;

	if((rcHeader.Width() > rcClient.Width()) || (rcHeader.left - nOffset < 0))
	{
		nScrollX = rcHeader.left - nOffset;
	}
	else if(rcHeader.right - nOffset > rcClient.right)
	{
		nScrollX = rcHeader.right - nOffset - rcClient.right;
	}

	if(nScrollX != 0)
	{
		CSize size(nScrollX, 0);
		if (Scroll(size)==FALSE)
			return FALSE;
	}

	return TRUE;
}

void CListCtrl_CellNav::OnLButtonDown(UINT nFlags, CPoint point)
{
	// Find out what subitem was clicked
	LVHITTESTINFO hitinfo = {0};
	hitinfo.flags = nFlags;
	hitinfo.pt = point;
	SubItemHitTest(&hitinfo);

	// Update the focused cell before calling CListCtrl::OnLButtonDown()
	// as it might cause a row-repaint
	m_FocusCell = hitinfo.iSubItem;
	CListCtrl::OnLButtonDown(nFlags, point);

	// CListCtrl::OnLButtonDown() doesn't always cause a row-repaint
	// call our own method to ensure the row is repainted
	UpdateFocusCell(hitinfo.iSubItem);
}

void CListCtrl_CellNav::OnRButtonDown(UINT nFlags, CPoint point)
{
	// Find out what subitem was clicked
	LVHITTESTINFO hitinfo = {0};
	hitinfo.flags = nFlags;
	hitinfo.pt = point;
	SubItemHitTest(&hitinfo);

	// If not right-clicking on an actual row, then don't update focus cell
	if (hitinfo.iItem==-1)
	{
		CListCtrl::OnRButtonDown(nFlags, point);
		return;
	}

	// Update the focused cell before calling CListCtrl::OnLButtonDown()
	// as it might cause a row-repaint
	m_FocusCell = hitinfo.iSubItem;
	CListCtrl::OnRButtonDown(nFlags, point);

	// CListCtrl::OnLButtonDown() doesn't always cause a row-repaint
	// call our own method to ensure the row is repainted
	UpdateFocusCell(hitinfo.iSubItem);
}

// Used instead of GetSubItemRect(), which returns the entire row-rect for label-column (nCol==0)
BOOL CListCtrl_CellNav::GetCellRect(int nRow, int nCol, CRect& rect)
{
	// Find the top and bottom of the cell-rectangle
	CRect rowRect;
	if (GetItemRect(nRow, rowRect, LVIR_BOUNDS)==FALSE)
		return FALSE;

	// Find the left and right of the cell-rectangle using the CHeaderCtrl
	CRect colRect;
	if (GetHeaderCtrl()->GetItemRect(nCol, colRect)==FALSE)
		return FALSE;

	// Adjust for scrolling
	colRect.left -= GetScrollPos(SB_HORZ);
	colRect.right -= GetScrollPos(SB_HORZ);

	rect.left = colRect.left;
	rect.top = rowRect.top;
	rect.right = colRect.right;
	rect.bottom = rowRect.bottom;
	return TRUE;
}

// Override custom-draw to display subitem selection
void CListCtrl_CellNav::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMLVCUSTOMDRAW* pLVCD = (NMLVCUSTOMDRAW*)(pNMHDR);
	int nRow = (int)pLVCD->nmcd.dwItemSpec;
	int nRowItemData = (int)pLVCD->nmcd.lItemlParam;

	switch (pLVCD->nmcd.dwDrawStage)
	{
		case CDDS_PREPAINT:
			*pResult |= CDRF_NOTIFYITEMDRAW;
			break;
		// Before painting a row
		case CDDS_ITEMPREPAINT:
		{
			if (pLVCD->nmcd.uItemState & CDIS_FOCUS)
			{
				// If drawing focus row, then remove focus state and request to draw it later
				//	- Row paint request can come twice, with and without focus flag
				//	- Only respond to the one with focus flag, else DrawFocusRect XOR will cause solid or blank focus-rectangle
				if (GetNextItem(-1, LVNI_FOCUSED)==nRow)
				{
					if (m_FocusCell >= 0)
					{
						// We want to draw a cell-focus-rectangle instead of row-focus-rectangle
						pLVCD->nmcd.uItemState &= ~CDIS_FOCUS;
						*pResult |= CDRF_NOTIFYPOSTPAINT;
					}
					else
					if (GetExtendedStyle() & LVS_EX_GRIDLINES)
					{
						// Avoid bug where bottom of focus rectangle is missing when using grid-lines
						//	- Draw the focus-rectangle for the entire row (explicit)
						pLVCD->nmcd.uItemState &= ~CDIS_FOCUS;
						*pResult |= CDRF_NOTIFYPOSTPAINT;
					}
				}
			}

			if (pLVCD->nmcd.uItemState & CDIS_SELECTED)
			{
				// Remove the selection color for the focus cell, to make it easier to see focus
				if (m_FocusCell!=-1)
					*pResult |= CDRF_NOTIFYSUBITEMDRAW;
			}
		} break;

		// Before painting a cell
		case CDDS_ITEMPREPAINT | CDDS_SUBITEM:
		{
			// Remove the selection color for the focus cell, to make it easier to see focus
			int nCol = pLVCD->iSubItem;
			if (pLVCD->nmcd.uItemState & CDIS_SELECTED && m_FocusCell==nCol && GetNextItem(-1, LVNI_FOCUSED)==nRow)
			{
				pLVCD->nmcd.uItemState &= ~CDIS_SELECTED;
			}
		} break;

		// After painting the entire row
		case CDDS_ITEMPOSTPAINT:
		{
			if (GetNextItem(-1, LVNI_FOCUSED)!=nRow)
				break;

			// Perform the drawing of the focus rectangle
			if (m_FocusCell >= 0)
			{
				// Draw the focus-rectangle for a single-cell
				CRect rcHighlight;
				CDC* pDC = CDC::FromHandle(pLVCD->nmcd.hdc);

				VERIFY( GetCellRect(nRow, m_FocusCell, rcHighlight) );

				// Adjust rectangle according to grid-lines
				if (GetExtendedStyle() & LVS_EX_GRIDLINES)
				{
					int cxborder = ::GetSystemMetrics(SM_CXBORDER);

					// Columns after the first visible column, has to take account of left-grid-border
					if (GetHeaderCtrl()->OrderToIndex(m_FocusCell)!=0)
						rcHighlight.left += cxborder;

					rcHighlight.bottom -= cxborder;
				}

				pDC->DrawFocusRect(rcHighlight);
			}
			else
			if (GetExtendedStyle() & LVS_EX_GRIDLINES)
			{
				// Avoid bug where bottom of focus rectangle is missing when using grid-lines
				//	- Draw the focus-rectangle for the entire row (explicit)
				CRect rcHighlight;
				CDC* pDC = CDC::FromHandle(pLVCD->nmcd.hdc);
				// Using LVIR_BOUNDS to get the entire row-rectangle
				VERIFY( GetItemRect(nRow, rcHighlight, LVIR_BOUNDS) );
				int cxborder = ::GetSystemMetrics(SM_CXBORDER);
				rcHighlight.bottom -= cxborder;
				pDC->DrawFocusRect(rcHighlight);
			}
		} break;
	}
}

// Keyboard search with subitems
void CListCtrl_CellNav::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (m_FocusCell<=0)
	{
		CListCtrl::OnChar(nChar, nRepCnt, nFlags);
		return;
	}

	// No input within 2 seconds, resets the search
	if (m_LastSearchTime.GetCurrentTime() >= (m_LastSearchTime+2)
	 && m_LastSearchString.GetLength()>0)
		m_LastSearchString = "";

	// Changing cells, resets the search
	if (m_LastSearchCell!=m_FocusCell)
		m_LastSearchString = "";

	// Changing rows, resets the search
	if (m_LastSearchRow!=GetNextItem(-1, LVNI_FOCUSED))
		m_LastSearchString = "";

	m_LastSearchCell = m_FocusCell;
	m_LastSearchTime = m_LastSearchTime.GetCurrentTime();

	if ( m_LastSearchString.GetLength()==1
	  && m_LastSearchString.GetAt(0)==nChar)
	{
		// When the same first character is entered again,
		// then just repeat the search
	}
	else
		m_LastSearchString.AppendChar(nChar);

	int nRow = GetNextItem(-1, LVNI_FOCUSED);
	if (nRow < 0)
		nRow = 0;
	int nCol = m_FocusCell;
	if (nCol < 0)
		nCol = GetHeaderCtrl()->OrderToIndex(0);
	int nRowCount = GetItemCount();

	// Perform the search loop twice
	//	- First search from current position down to bottom
	//	- Then search from top to current position
	for(int j = 0; j < 2; ++j)
	{
		for(int i = nRow + 1; i < nRowCount; ++i)
		{
			CString cellText = GetItemText(i, nCol);
			if (cellText.GetLength()>=m_LastSearchString.GetLength())
			{
				cellText.Truncate(m_LastSearchString.GetLength());
				if (cellText.CompareNoCase(m_LastSearchString)==0)
				{
					// De-select all other rows
					SetItemState(-1, 0, LVIS_SELECTED);
					// Select row found
					SetItemState(i, LVIS_SELECTED, LVIS_SELECTED);
					// Focus row found
					SetItemState(i, LVIS_FOCUSED, LVIS_FOCUSED);	
					// Scroll to row found
					EnsureVisible(i, FALSE);			
					m_LastSearchRow = i;
					return;
				}
			}
		}
		nRowCount = nRow;
		nRow = -1;
	}
}

namespace {
	LRESULT EnableWindowTheme(HWND hwnd, LPCWSTR classList, LPCWSTR subApp, LPCWSTR idlist)
	{
		HMODULE hinstDll;
		HRESULT (__stdcall *pSetWindowTheme)(HWND hwnd, LPCWSTR pszSubAppName, LPCWSTR pszSubIdList);
		HANDLE (__stdcall *pOpenThemeData)(HWND hwnd, LPCWSTR pszClassList);
		HRESULT (__stdcall *pCloseThemeData)(HANDLE hTheme);

		hinstDll = ::LoadLibrary("UxTheme.dll");
		if (hinstDll)
		{
			(FARPROC&)pOpenThemeData = ::GetProcAddress(hinstDll, TEXT("OpenThemeData"));
			(FARPROC&)pCloseThemeData = ::GetProcAddress(hinstDll, TEXT("CloseThemeData"));
			(FARPROC&)pSetWindowTheme = ::GetProcAddress(hinstDll, TEXT("SetWindowTheme"));
			::FreeLibrary(hinstDll);
			if (pSetWindowTheme && pOpenThemeData && pCloseThemeData)
			{
				HANDLE theme = pOpenThemeData(hwnd,classList);
				if (theme!=NULL)
				{
					VERIFY(pCloseThemeData(theme)==S_OK);
					return pSetWindowTheme(hwnd, subApp, idlist);
				}
			}
		}
		return S_FALSE;
	}
}

void CListCtrl_CellNav::PreSubclassWindow()
{
	CListCtrl::PreSubclassWindow();

	// Focus retangle is not painted properly without double-buffering
#if (_WIN32_WINNT >= 0x501)
	SetExtendedStyle(LVS_EX_DOUBLEBUFFER | GetExtendedStyle());
#endif
	SetExtendedStyle(GetExtendedStyle() | LVS_EX_FULLROWSELECT);
	SetExtendedStyle(GetExtendedStyle() | LVS_EX_HEADERDRAGDROP);
	SetExtendedStyle(GetExtendedStyle() | LVS_EX_GRIDLINES);

	// Enable Vista-look if possible
	EnableWindowTheme(GetSafeHwnd(), L"ListView", L"Explorer", NULL);
}