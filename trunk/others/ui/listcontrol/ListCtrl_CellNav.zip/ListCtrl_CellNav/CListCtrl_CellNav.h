#pragma once

// Cell-Navigation + Clipboard
class CListCtrl_CellNav : public CListCtrl
{
protected:
	int m_FocusCell;

	// Keyboard search
	CString m_LastSearchString;
	CTime	m_LastSearchTime;
	int		m_LastSearchCell;
	int		m_LastSearchRow;

	DECLARE_MESSAGE_MAP()

	void MoveFocusCell(bool right);
	void UpdateFocusCell(int nCol);
	BOOL EnsureColumnVisible(int nCol, bool bPartialOK);
	BOOL GetCellRect(int nRow, int nCol, CRect& rect);

	virtual afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	virtual afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	virtual afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	virtual afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	virtual afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);

	virtual void PreSubclassWindow();

public:
	CListCtrl_CellNav()
		:m_FocusCell(-1)
		,m_LastSearchCell(-1)
		,m_LastSearchRow(-1)
	{}
};