#pragma once

#include "CListCtrl_ToolTip.h"

class CListCtrl_EnableToolTip : public CListCtrl_ToolTip
{
	DECLARE_MESSAGE_MAP();

	virtual INT_PTR OnToolHitTest(CPoint point, TOOLINFO * pTI) const;
	virtual void PreSubclassWindow();
};