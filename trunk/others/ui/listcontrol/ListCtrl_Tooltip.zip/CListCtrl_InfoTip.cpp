#include "stdafx.h"
#include "CListCtrl_InfoTip.h"

BEGIN_MESSAGE_MAP(CListCtrl_InfoTip, CListCtrl)
	ON_NOTIFY_REFLECT_EX(LVN_GETINFOTIP, OnGetInfoTip)
END_MESSAGE_MAP()

void CListCtrl_InfoTip::PreSubclassWindow()
{
	CListCtrl_ToolTip::PreSubclassWindow();
	SetExtendedStyle(LVS_EX_INFOTIP | GetExtendedStyle());
}

BOOL CListCtrl_InfoTip::OnGetInfoTip(NMHDR* pNMHDR, LRESULT* pResult)
{
	// Will only request tooltip for the label-column
	NMLVGETINFOTIP* pInfoTip = (NMLVGETINFOTIP*)pNMHDR;
	CString tooltip = GetToolTipText(pInfoTip->iItem, pInfoTip->iSubItem);
	if (!tooltip.IsEmpty())
	{
		_tcsncpy(pInfoTip->pszText, tooltip.GetString(), pInfoTip->cchTextMax);
	}
	return FALSE;	// Let parent-dialog get chance
}