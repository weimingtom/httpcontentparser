#pragma once

#include "CListCtrl_ToolTip.h"

class CListCtrl_OwnToolTipCtrl : public CListCtrl_ToolTip
{
	int m_LastToolTipCol;
	int m_LastToolTipRow;

	CToolTipCtrl m_OwnToolTipCtrl;

	virtual void PreSubclassWindow();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnToolNeedText(UINT id, NMHDR* pNMHDR, LRESULT* pResult);

	DECLARE_MESSAGE_MAP();

public:
	CListCtrl_OwnToolTipCtrl()
		:m_LastToolTipCol(-1)
		,m_LastToolTipRow(-1)
	{}
};