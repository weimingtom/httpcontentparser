#pragma once

#include "CListCtrl_ToolTip.h"

class CListCtrl_InfoTip : public CListCtrl_ToolTip
{
	virtual void PreSubclassWindow();

	afx_msg BOOL OnGetInfoTip(NMHDR* pNMHDR, LRESULT* pResult);

	DECLARE_MESSAGE_MAP();
};