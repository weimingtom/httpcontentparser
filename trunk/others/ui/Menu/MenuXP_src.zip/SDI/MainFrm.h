// MainFrm.h : interface of the CMainFrame class
//

#pragma once

#include "../Tools/MenuXP.h"
#include "../Tools/ToolBarXP.h"
#include "../Tools/StatusBarXP.h"
#include "../Tools/ComboBoxXP.h"

class CMainFrame : public CFrameWnd
{
	DECLARE_DYNCREATE(CMainFrame)
public:
	CMainFrame();

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL LoadFrame(UINT nIDResource,
				DWORD dwDefaultStyle = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE,
				CWnd* pParentWnd = NULL,
				CCreateContext* pContext = NULL);

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBarXP m_wndStatusBar;
	CToolBarXP   m_wndToolBar;
	CToolBar     m_wndOtherBar;
    CComboBoxXP  m_cboFind;

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnMRUFileOpen();
	DECLARE_MESSAGE_MAP()
    DECLARE_MENUXP()
};


