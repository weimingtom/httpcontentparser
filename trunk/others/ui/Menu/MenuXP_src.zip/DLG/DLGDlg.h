// DLGDlg.h : header file
//

#pragma once

#include "../Tools/MenuXP.h"
#include "../Tools/ButtonXP.h"
#include "../Tools/ComboBoxXP.h"

// CDLGDlg dialog
class CDLGDlg : public CDialog
{
// Construction
public:
	CDLGDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_DLG_DIALOG };
	CComboBoxXP m_cboName;
	CButtonXP m_btnOk;
	CButtonXP m_btnCancel;
	CImageList m_imgList;

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAppAbout();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint pt);
	DECLARE_MESSAGE_MAP()
    DECLARE_MENUXP()
};
