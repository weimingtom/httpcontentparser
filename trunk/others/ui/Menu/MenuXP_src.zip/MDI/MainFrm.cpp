// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Demo.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)
IMPLEMENT_MENUXP(CMainFrame, CMDIFrameWnd);

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	ON_WM_CREATE()
    ON_COMMAND(DROPDOWN(ID_FILE_OPEN), OnMRUFileOpen)
    ON_MENUXP_MESSAGES()
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

void CMainFrame::OnUpdateFrameMenu (HMENU hMenuAlt)
{
    CMDIFrameWnd::OnUpdateFrameMenu (hMenuAlt);
    CMenuXP::UpdateMenuBar (this);
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

    // Comment this line to deactivate the XP Look & Feel
    CMenuXP::SetXPLookNFeel (this);
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
    m_wndToolBar.SetButtonStyle (m_wndToolBar.CommandToIndex (ID_FILE_OPEN), m_wndToolBar.GetButtonStyle(m_wndToolBar.CommandToIndex (ID_FILE_OPEN))|TBSTYLE_DROPDOWN);

    m_cboFind.Create (WS_CHILD|WS_VISIBLE|CBS_DROPDOWN|CBS_AUTOHSCROLL, CRect(0,0,150,15), &m_wndToolBar, ID_EDIT_FIND);
    m_cboFind.InsertString (0, _T("String one"));
    m_cboFind.InsertString (1, _T("String two"));
    m_cboFind.InsertString (2, _T("String three"));
    m_cboFind.SetCurSel (0);
    m_wndToolBar.InsertControl (11, m_cboFind);

	if (!m_wndOtherBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndOtherBar.LoadToolBar(IDR_OTHERBAR))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	// TODO: Delete these three lines if you don't want the toolbar to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}


// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers

///////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnMRUFileOpen ()
{
    CMenu Menu;

    Menu.CreatePopupMenu();
    Menu.InsertMenu (0, MF_BYPOSITION, ID_FILE_MRU_FIRST, _T("Recent File"));
    m_wndToolBar.TrackPopupMenu (ID_FILE_OPEN, &Menu);
}
