// ChildFrm.h : interface of the CChildFrame class
//

#pragma once

#include "../Tools/MenuXP.h"

class CChildFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CChildFrame)
public:
	CChildFrame();

// Attributes
public:
    UINT m_nRadioID;

// Operations
public:

// Overrides
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
    virtual void OnUpdateFrameMenu (BOOL bActivate, CWnd* pActivateWnd, HMENU hMenuAlt);

// Implementation
public:
	virtual ~CChildFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
    int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnRadioItem(UINT nID);
	afx_msg void OnUpdateRadioItem(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
    DECLARE_MENUXP()
};
