// ChildFrm.cpp : implementation of the CChildFrame class
//
#include "stdafx.h"
#include "Demo.h"

#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)
IMPLEMENT_MENUXP(CChildFrame, CMDIChildWnd);

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	ON_WM_CREATE()
    ON_COMMAND_RANGE(ID_RADIO_ITEM1, ID_RADIO_ITEM3, OnRadioItem)
    ON_UPDATE_COMMAND_UI_RANGE(ID_RADIO_ITEM1, ID_RADIO_ITEM3, OnUpdateRadioItem)
    ON_MENUXP_MESSAGES()
END_MESSAGE_MAP()


// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	// TODO: add member initialization code here
	m_nRadioID = ID_RADIO_ITEM1;
}

CChildFrame::~CChildFrame()
{
}


BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying the CREATESTRUCT cs
	if( !CMDIChildWnd::PreCreateWindow(cs) )
		return FALSE;

	cs.style = WS_CHILD | WS_VISIBLE | WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU
		| FWS_ADDTOTITLE | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE;

	return TRUE;
}

void CChildFrame::OnUpdateFrameMenu (BOOL bActivate, CWnd* pActivateWnd, HMENU hMenuAlt)
{
    CMDIChildWnd::OnUpdateFrameMenu (bActivate, pActivateWnd, hMenuAlt);
    CMenuXP::UpdateMenuBar (GetMDIFrame());

    HMENU hMenu = GetSystemMenu (false)->GetSafeHmenu();

    if ( hMenu != NULL )
    {
        CMenuXP::SetXPLookNFeel (this, hMenu, true);
    }
}

int CChildFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

    // Comment this line to deactivate the XP Look & Feel
    CMenuXP::SetXPLookNFeel (this);

	return 0;
}


// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG


#define SetMenuBarText(MenuBar,Index,Text) MenuBar->ModifyMenu (nOffsetMenuPos+Index,MF_BYPOSITION|MF_POPUP,(UINT)MenuBar->GetSubMenu(nOffsetMenuPos+Index)->GetSafeHmenu(),Text);
#define SetMenuItemText(Menu,Index,Text) mii.dwTypeData=Text;::SetMenuItemInfo(Menu->GetSafeHmenu(),Index,true,&mii);

// CChildFrame message handlers

///////////////////////////////////////////////////////////////////////////////
void CChildFrame::OnRadioItem (UINT nID)
{
    m_nRadioID = nID;
    
    CMenu* pMenuBar = GetMDIFrame()->GetMenu();
    int nOffsetMenuPos = IsZoomed() ? 1 : 0;
    CMenu* pFileMenu = pMenuBar->GetSubMenu (nOffsetMenuPos+0);
    MENUITEMINFO mii = { sizeof MENUITEMINFO, MIIM_TYPE };

    switch ( nID )
    {
    case ID_RADIO_ITEM1:
        SetMenuBarText (pMenuBar, 0, "&File");
        SetMenuItemText (pFileMenu, 0, "&New\tCtrl+N");
        SetMenuItemText (pFileMenu, 1, "&Open...\tCtrl+O");
        SetMenuItemText (pFileMenu, 2, "&Close");
        SetMenuItemText (pFileMenu, 3, "&Save\tCtrl+S");
        SetMenuItemText (pFileMenu, 4, "Save &As...");
        SetMenuBarText (pMenuBar, 1, "&Edit");
        SetMenuBarText (pMenuBar, 2, "&View");
        SetMenuBarText (pMenuBar, 3, "&Language");
        SetMenuBarText (pMenuBar, 4, "&Window");
        SetMenuBarText (pMenuBar, 5, "&Help");
        // TODO: translate other items...
        break;
        
    case ID_RADIO_ITEM2:
        SetMenuBarText (pMenuBar, 0, "&Fichier");
        SetMenuItemText (pFileMenu, 0, "&Nouveau\tCtrl+N");
        SetMenuItemText (pFileMenu, 1, "&Ouvrir...\tCtrl+O");
        SetMenuItemText (pFileMenu, 2, "&Fermer");
        SetMenuItemText (pFileMenu, 3, "&Enregistrer\tCtrl+S");
        SetMenuItemText (pFileMenu, 4, "En&registrer sous...");
        SetMenuBarText (pMenuBar, 1, "&Edition");
        SetMenuBarText (pMenuBar, 2, "&Affichage");
        SetMenuBarText (pMenuBar, 3, "&Langue");
        SetMenuBarText (pMenuBar, 4, "Fe&n�tre");
        SetMenuBarText (pMenuBar, 5, "&Aide");
        // TODO: translate other items...
        break;
        
    case ID_RADIO_ITEM3:
        SetMenuBarText (pMenuBar, 0, "&Datei");
        SetMenuItemText (pFileMenu, 0, "&Neu\tStrg+N");
        SetMenuItemText (pFileMenu, 1, "�&ffnen...\tStrg+O");
        SetMenuItemText (pFileMenu, 2, "&Schlie�en");
        SetMenuItemText (pFileMenu, 3, "&Speichern\tStrg+S");
        SetMenuItemText (pFileMenu, 4, "Speichern &unter...");
        SetMenuBarText (pMenuBar, 1, "&Bearbeiten");
        SetMenuBarText (pMenuBar, 2, "&Ansicht");
        SetMenuBarText (pMenuBar, 3, "&Sprache");
        SetMenuBarText (pMenuBar, 4, "&Fenster");
        SetMenuBarText (pMenuBar, 5, "&Hilfe");
        // TODO: translate other items...
        break;
    }
    CMenuXP::UpdateMenuBar (GetMDIFrame());
    GetMDIFrame()->DrawMenuBar();
}

///////////////////////////////////////////////////////////////////////////////
void CChildFrame::OnUpdateRadioItem (CCmdUI* pCmdUI)
{
    if ( pCmdUI->m_nID == m_nRadioID )
    {
        pCmdUI->m_pMenu->CheckMenuRadioItem (ID_RADIO_ITEM1, ID_RADIO_ITEM3, pCmdUI->m_nID, MF_BYCOMMAND);
    }
}
