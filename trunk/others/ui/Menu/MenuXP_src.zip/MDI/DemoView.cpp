// DemoView.cpp : implementation of the CDemoView class
//

#include "stdafx.h"
#include "Demo.h"
#include "DemoDoc.h"
#include "CntrItem.h"
#include "DemoView.h"
#include "../Tools/Tools.h"
#include "../Tools/Draw.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDemoView

IMPLEMENT_DYNCREATE(CDemoView, CRichEditView)

BEGIN_MESSAGE_MAP(CDemoView, CRichEditView)
	ON_WM_DESTROY()
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CRichEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CRichEditView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_EDIT_ITEM2, CRichEditView::OnEditCut)
	ON_COMMAND(ID_EDIT_ITEM4, CRichEditView::OnEditPaste)
	ON_COMMAND(ID_EDIT_ITEM6, CRichEditView::OnEditFind)
	ON_COMMAND(ID_EDIT_ITEM8, CRichEditView::OnEditReplace)
    ON_WM_NCPAINT()
END_MESSAGE_MAP()

// CDemoView construction/destruction

CDemoView::CDemoView()
{
	// TODO: add construction code here

}

CDemoView::~CDemoView()
{
}

BOOL CDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRichEditView::PreCreateWindow(cs);
}

void CDemoView::OnInitialUpdate()
{
	CRichEditView::OnInitialUpdate();

	// Set the printing margins (720 twips = 1/2 inch)
	SetMargins(CRect(720, 720, 720, 720));
	// Set flat border
    ModifyStyle (0, WS_BORDER);
    ModifyStyleEx (WS_EX_CLIENTEDGE, 0);
    GetParentFrame()->RecalcLayout();
}


// CDemoView printing

BOOL CDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}


void CDemoView::OnDestroy()
{
	// Deactivate the item on destruction; this is important
	// when a splitter view is being used
   COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
   if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
   {
      pActiveItem->Deactivate();
      ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
   }
   CRichEditView::OnDestroy();
}



// CDemoView diagnostics

#ifdef _DEBUG
void CDemoView::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CDemoView::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}

CDemoDoc* CDemoView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDemoDoc)));
	return (CDemoDoc*)m_pDocument;
}
#endif //_DEBUG


// CDemoView message handlers

void CDemoView::OnRButtonDown (UINT nFlags, CPoint pt)
{
	CRichEditView::OnRButtonDown (nFlags, pt);
    ClientToScreen (&pt);
    SendMessage (WM_CONTEXTMENU, (WPARAM)m_hWnd, MAKELPARAM(pt.x, pt.y));
}

void CDemoView::OnContextMenu (CWnd*, CPoint pt)
{
    CMenu mnu;
    VERIFY(mnu.LoadMenu (IDR_POPUPMENU));
    CMenu* pPopup = mnu.GetSubMenu (0);

    if ( pPopup != NULL )
    {
        if ( pt.x < 0 || pt.y < 0 )
        {
            pt = GetCaretPos();
            ClientToScreen (&pt);
            pt.x += 2;
            pt.y += 14;
        }
        pPopup->TrackPopupMenu (TPM_RIGHTBUTTON, pt.x, pt.y, GetParentFrame());
    }
}

///////////////////////////////////////////////////////////////////////////////
void CDemoView::CalcWindowRect (LPRECT lpClientRect, UINT nAdjustType)
{
    CView::CalcWindowRect (lpClientRect, nAdjustType);

	if ( nAdjustType == 0 )
    {
        ::InflateRect (lpClientRect, -1, -1);
    }
}

///////////////////////////////////////////////////////////////////////////////
// Draw flat border
void CDemoView::OnNcPaint ()
{
    Default();

    CWindowDC cDC (this);
    CWindowRect rc (this);
    CPenDC pen (cDC, ::GetSysColor (COLOR_3DSHADOW));
    CBrushDC brush (cDC);
    cDC.Rectangle (0, 0, rc.Width(), rc.Height());
}
