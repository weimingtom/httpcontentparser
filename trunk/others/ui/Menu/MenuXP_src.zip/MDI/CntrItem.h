// CntrItem.h : interface of the CDemoCntrItem class
//

#pragma once

class CDemoDoc;
class CDemoView;

class CDemoCntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CDemoCntrItem)

// Constructors
public:
	CDemoCntrItem(REOBJECT* preo = NULL, CDemoDoc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer

// Attributes
public:
	CDemoDoc* GetDocument()
		{ return reinterpret_cast<CDemoDoc*>(CRichEditCntrItem::GetDocument()); }
	CDemoView* GetActiveView()
		{ return reinterpret_cast<CDemoView*>(CRichEditCntrItem::GetActiveView()); }

	public:
	protected:

// Implementation
public:
	~CDemoCntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

