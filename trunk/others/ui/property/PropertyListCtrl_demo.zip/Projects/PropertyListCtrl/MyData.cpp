// MyData.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
//
// Copyright � 1999, Stefan Belopotocan, http://welcome.to/StefanBelopotocan
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MyData.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyItemListYesNo

BEGIN_LIST_ITEM_DATA_TYPE(CPropertyItemListYesNo)
	LPCTSTR_STRING_ITEM_DATA(_T("No")),
	LPCTSTR_STRING_ITEM_DATA(_T("Yes"))
END_LIST_ITEM_DATA_TYPE(CPropertyItemListYesNo)

/////////////////////////////////////////////////////////////////////////////
// CPropertyItemListDataType

BEGIN_LIST_ITEM_DATA_TYPE(CPropertyItemListDataType)
	LPCTSTR_STRING_ITEM_DATA(_T("Only data")),
	LPCTSTR_STRING_ITEM_DATA(_T("Input line")),
	LPCTSTR_STRING_ITEM_DATA(_T("Data item")),
	LPCTSTR_STRING_ITEM_DATA(_T("List")),
	LPCTSTR_STRING_ITEM_DATA(_T("Form")),
	LPCTSTR_STRING_ITEM_DATA(_T("Macro"))
END_LIST_ITEM_DATA_TYPE(CPropertyItemListDataType)

/////////////////////////////////////////////////////////////////////////////
// CPropertyItemListDataFormatType

BEGIN_LIST_ITEM_DATA_TYPE(CPropertyItemListDataFormatType)
	LPCTSTR_STRING_ITEM_DATA(_T("Number")),
	LPCTSTR_STRING_ITEM_DATA(_T("Currency")),
	LPCTSTR_STRING_ITEM_DATA(_T("Time")),
	LPCTSTR_STRING_ITEM_DATA(_T("Date")),
	LPCTSTR_STRING_ITEM_DATA(_T("Other type"))
END_LIST_ITEM_DATA_TYPE(CPropertyItemListDataFormatType)

/////////////////////////////////////////////////////////////////////////////
// CMyData

CMyData::CMyData()
{
	m_strName = _T("XXyy");
	m_strDescription = _T("Only sample");
	m_bBindDatabaseData = false;
	m_strDbTableColumn = _T("TABLE.COLUMN");
	m_bCreateHistoryData = false;
	m_nDataType = 1;
	m_nFormatDataType = 0;
}

/////////////////////////////////////////////////////////////////////////////
// CMyStaticPropertyItemManager

CMyStaticPropertyItemManager::CMyStaticPropertyItemManager()
{
	//////////////////////////////////////////////////////////////////////////
	// V�eobecn� 	
	BEGIN_PROPERTY_TAB(_T("General"), true)
		PROPERTY_ITEM(ID_PD_NAME, CPropertyItemString, _T("Name"), true)
		PROPERTY_ITEM(ID_PD_DESCRIPTION, CPropertyItemString, _T("Description"), true)
		PROPERTY_ITEM(ID_PD_BIND_DATA, CPropertyItemListYesNo, _T("Data binding"), true)
	END_PROPERTY_TAB()

	//////////////////////////////////////////////////////////////////////////
	// D�ta
	BEGIN_PROPERTY_TAB(_T("Data"), true)
		PROPERTY_ITEM(ID_PD_DB_NODE, CPropertyItemString, _T("Db data node"), true)
		PROPERTY_ITEM(ID_PD_HISTORY, CPropertyItemListYesNo, _T("History"), true)
	END_PROPERTY_TAB()
}

CMyStaticPropertyItemManager::~CMyStaticPropertyItemManager()
{
}

bool CMyStaticPropertyItemManager::SetData(const CObject* pData)
{
	const CMyData* pMyData = static_cast<const CMyData*>(pData);

	BEGIN_ITERATE_PROPERTY_ITEMS()
		SET_ITEM_STRING(ID_PD_NAME, pMyData->m_strName)
		SET_ITEM_STRING(ID_PD_DESCRIPTION, pMyData->m_strDescription)
		SET_ITEM_LIST(ID_PD_BIND_DATA, pMyData->m_bBindDatabaseData)
		SET_ITEM_STRING(ID_PD_DB_NODE, pMyData->m_strDbTableColumn)
		SET_ITEM_LIST(ID_PD_HISTORY, pMyData->m_bCreateHistoryData)
	END_ITERATE_PROPERTY_ITEMS()

	return true;
}

bool CMyStaticPropertyItemManager::GetData(CObject* pData) const
{
	CMyData* pMyData = static_cast<CMyData*>(pData);

	BEGIN_ITERATE_PROPERTY_ITEMS()
		GET_ITEM_STRING(ID_PD_NAME, pMyData->m_strName)
		GET_ITEM_STRING(ID_PD_DESCRIPTION, pMyData->m_strDescription)
		GET_ITEM_LIST(ID_PD_BIND_DATA, pMyData->m_bBindDatabaseData)
		GET_ITEM_STRING(ID_PD_DB_NODE, pMyData->m_strDbTableColumn)
		GET_ITEM_LIST(ID_PD_HISTORY, pMyData->m_bCreateHistoryData)
	END_ITERATE_PROPERTY_ITEMS()

	return true;
}

/////////////////////////////////////////////////////////////////////////////
// CMyAdaptablePropertyItemManager

CMyAdaptablePropertyItemManager::CMyAdaptablePropertyItemManager()
{
	//////////////////////////////////////////////////////////////////////////
	// V�eobecn� 	
	BEGIN_PROPERTY_TAB(_T("General"), true)
		PROPERTY_ITEM(ID_PD_NAME, CPropertyItemString, _T("Name"), true)
		PROPERTY_ITEM(ID_PD_DESCRIPTION, CPropertyItemString, _T("Description"), true)
		PROPERTY_ITEM(ID_PD_BIND_DATA, CPropertyItemListYesNo, _T("Data binding"), true)
	END_PROPERTY_TAB()

	//////////////////////////////////////////////////////////////////////////
	// D�ta
	BEGIN_PROPERTY_TAB(_T("Data"), false)
		PROPERTY_ITEM(ID_PD_DB_NODE, CPropertyItemString, _T("Db data node"), true)
		PROPERTY_ITEM(ID_PD_HISTORY, CPropertyItemListYesNo, _T("History"), true)
		PROPERTY_ITEM(ID_PD_DATA_TYPE, CPropertyItemListDataType, _T("Data typ"), true)
	END_PROPERTY_TAB()

	//////////////////////////////////////////////////////////////////////////
	// Form�t d�t
	BEGIN_PROPERTY_TAB(_T("Data format"), false)
		PROPERTY_ITEM(ID_PD_FORMAT_DATA_TYPE, CPropertyItemListDataFormatType, _T("Type of data format"), true)
	END_PROPERTY_TAB()
}

CMyAdaptablePropertyItemManager::~CMyAdaptablePropertyItemManager()
{
}

bool CMyAdaptablePropertyItemManager::SetData(const CObject* pData)
{
	const CMyData* pMyData = static_cast<const CMyData*>(pData);

	BEGIN_ITERATE_PROPERTY_ITEMS()
		SET_ITEM_STRING(ID_PD_NAME, pMyData->m_strName)
		SET_ITEM_STRING(ID_PD_DESCRIPTION, pMyData->m_strDescription)
		SET_ITEM_LIST(ID_PD_BIND_DATA, pMyData->m_bBindDatabaseData)
		SET_ITEM_STRING(ID_PD_DB_NODE, pMyData->m_strDbTableColumn)
		SET_ITEM_LIST(ID_PD_HISTORY, pMyData->m_bCreateHistoryData)
		SET_ITEM_LIST(ID_PD_DATA_TYPE, pMyData->m_nDataType)
		SET_ITEM_LIST(ID_PD_FORMAT_DATA_TYPE, pMyData->m_nFormatDataType)
	END_ITERATE_PROPERTY_ITEMS()

	return true;
}

bool CMyAdaptablePropertyItemManager::GetData(CObject* pData) const
{
	CMyData* pMyData = static_cast<CMyData*>(pData);

	BEGIN_ITERATE_PROPERTY_ITEMS()
		GET_ITEM_STRING(ID_PD_NAME, pMyData->m_strName)
		GET_ITEM_STRING(ID_PD_DESCRIPTION, pMyData->m_strDescription)
		GET_ITEM_LIST(ID_PD_BIND_DATA, pMyData->m_bBindDatabaseData)
		GET_ITEM_STRING(ID_PD_DB_NODE, pMyData->m_strDbTableColumn)
		GET_ITEM_LIST(ID_PD_HISTORY, pMyData->m_bCreateHistoryData)
		GET_ITEM_LIST(ID_PD_DATA_TYPE, pMyData->m_nDataType)
		GET_ITEM_LIST(ID_PD_FORMAT_DATA_TYPE, pMyData->m_nFormatDataType)
	END_ITERATE_PROPERTY_ITEMS()

	return true;
}

void CMyAdaptablePropertyItemManager::OnDataChanged(CPropertyItem* pPropertyItem, CPropertyListCtrl* pWndPropertyListCtrl, int nIndex)
{
	bool bDoChecking = false;

	switch(pPropertyItem->GetPropertyID())
	{
		case ID_PD_BIND_DATA:
			{
			// Yes/No item
			bool bEnableTabs;
			static_cast<CPropertyItemList*>(pPropertyItem)->GetData(bEnableTabs);

			// Enable/Disable tabs 1
			CPropertyItemCategory* pPropertyItemTab = GetCategoryTab(1);

			if(pPropertyItemTab->SetEnabled(bEnableTabs))
				bDoChecking = true;
			
			// Enable/Disable tabs 2
			int nItemType;
			static_cast<CPropertyItemList*>(pPropertyItemTab->GetPropertyItem(ID_PD_DATA_TYPE))->GetData(nItemType);

			pPropertyItemTab = GetCategoryTab(2);

			if(pPropertyItemTab->SetEnabled(bEnableTabs && nItemType < 4))
				bDoChecking = true;
			}
			break;
		case ID_PD_DATA_TYPE:
			{
			// Enumerate item
			int nItemType;
			static_cast<CPropertyItemList*>(pPropertyItem)->GetData(nItemType);

			// For items 4 (Form) and 5 (Macro) disable tab #2, for others enable			
			CPropertyItemCategory* pPropertyItemTab = GetCategoryTab(2);
			bDoChecking = pPropertyItemTab->SetEnabled(nItemType < 4);
			}
			break;
		default:
			return;
	}

	if(bDoChecking)
		CheckState(pWndPropertyListCtrl, nIndex, pPropertyItem->GetPropertyID());
}