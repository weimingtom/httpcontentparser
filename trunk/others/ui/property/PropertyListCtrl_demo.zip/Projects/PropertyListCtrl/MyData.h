#if !defined(_MYDATA_H)
#define _MYDATA_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyData.h : header file
//
/////////////////////////////////////////////////////////////////////////////
//
// Copyright � 1999, Stefan Belopotocan, http://welcome.to/StefanBelopotocan
//
/////////////////////////////////////////////////////////////////////////////

#include "PropertyListCtrl.h"

#define ID_PD_NAME				1
#define ID_PD_DESCRIPTION		2
#define ID_PD_BIND_DATA			3

#define ID_PD_DB_NODE			4
#define ID_PD_HISTORY			5
#define ID_PD_DATA_TYPE			6

#define ID_PD_FORMAT_DATA_TYPE	7

class CMyStaticPropertyItemManager;
class CMyAdaptablePropertyItemManager;

// Only as an example
/////////////////////////////////////////////////////////////////////////////
// CMyData

class CMyData : public CObject
{
	CMyData(const CMyData& d);
	CMyData& operator=(const CMyData& d);

public:
	CMyData();
	~CMyData();

	// Data
private:
	CString m_strName;
	CString m_strDescription;
	bool m_bBindDatabaseData;
	CString m_strDbTableColumn;
	BOOL m_bCreateHistoryData;
	int m_nDataType;
	int m_nFormatDataType;

	friend CMyStaticPropertyItemManager;
	friend CMyAdaptablePropertyItemManager;
};

inline CMyData::~CMyData()
{
}


/////////////////////////////////////////////////////////////////////////////
// CMyStaticPropertyItemManager

class CMyStaticPropertyItemManager : public CPropertyItemManager
{
	CMyStaticPropertyItemManager(const CMyStaticPropertyItemManager& d);
	CMyStaticPropertyItemManager& operator=(const CMyStaticPropertyItemManager& d);

public:
	CMyStaticPropertyItemManager();
	~CMyStaticPropertyItemManager();

	bool SetData(const CObject* pData);
	bool GetData(CObject* pData) const;
};


/////////////////////////////////////////////////////////////////////////////
// CMyAdaptablePropertyItemManager

class CMyAdaptablePropertyItemManager : public CPropertyItemManagerAdaptable
{
	CMyAdaptablePropertyItemManager(const CMyAdaptablePropertyItemManager& d);
	CMyAdaptablePropertyItemManager& operator=(const CMyAdaptablePropertyItemManager& d);

public:
	CMyAdaptablePropertyItemManager();
	~CMyAdaptablePropertyItemManager();

	bool SetData(const CObject* pData);
	bool GetData(CObject* pData) const;

	void OnDataChanged(CPropertyItem* pPropertyItem, CPropertyListCtrl* pWndPropertyListCtrl, int nIndex);
};

#endif // !defined(AFX_PROPERTYLISTCTRLDLG_H__466FB4E7_6072_11D3_A7E3_006008C8B630__INCLUDED_)